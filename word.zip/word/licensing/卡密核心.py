"""授权码（卡密）核心库：Ed25519 签发与校验，仅依赖标准库。

设计要点
--------
* **非对称**：签发方用私钥签名，被保护程序只内嵌公钥。程序被反编译也拿不到私钥，
  因此无法自行伪造卡密 —— 这是本方案相对"程序内置共享密钥"的关键优势。
* **纯标准库**：Ed25519 用纯 Python 实现（RFC 8032），不引入任何第三方依赖。
  速度足够：签/验各约 10~20 ms，卡密校验不是性能敏感路径。
* **可读格式**：``WSK1-XXXX-XXXX-...``，Base32 编码，肉眼可抄写、可区分。

卡密载荷（payload）字段
-----------------------
``v``   版本号
``id``  卡密唯一编号（用于台账/吊销）
``exp`` 到期日 ``YYYYMMDD``；``0`` 表示永久
``mid`` 绑定机器码；空字符串表示不绑定
``n``   授权名称/备注（如客户名），仅作标识
``iat`` 签发时间戳

被保护程序需要持有的东西
------------------------
1. 公钥（32 字节，Base32 文本）—— 内嵌在程序里
2. 可选的吊销名单 —— 从台账导出

被保护程序**绝不能**持有的东西：私钥。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import secrets
import struct
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "LicenseError",
    "KeyPair",
    "License",
    "generate_keypair",
    "issue",
    "verify",
    "machine_id",
    "encode_key",
    "decode_key",
    "PREFIX",
]

PREFIX = "WSK1"
# 字段布局（字节）：版本 1 + 到期 4 + 编号 16 + 机器 8 + 名称 24 + 签发 4
# 名称给到 24 字节，够放 8 个汉字；旧的 16 字节装 5 个汉字就溢出被截断。
FIELD_KEY_ID = 16
FIELD_MACHINE = 8
FIELD_NAME = 24
PAYLOAD_HEAD = 1 + 4 + FIELD_KEY_ID + FIELD_MACHINE + FIELD_NAME + 4  # = 57
PAYLOAD_BYTES = 84  # 头部 + 预留空间
SIGNATURE_BYTES = 64
KEY_BYTES = PAYLOAD_BYTES + SIGNATURE_BYTES


class LicenseError(Exception):
    """卡密相关的所有错误。"""


# ==========================================================================
# Ed25519（RFC 8032）—— 纯 Python 实现
# ==========================================================================
_P = 2**255 - 19
_Q = 2**252 + 27742317777372353535851937790883648493  # 曲线子群阶
_D = (-121665 * pow(121666, _P - 2, _P)) % _P
_I = pow(2, (_P - 1) // 4, _P)  # sqrt(-1)


def _sha512(data: bytes) -> bytes:
    return hashlib.sha512(data).digest()


def _recover_x(y: int, sign: int) -> int:
    """由 y 还原 x（模 p 开方），失败抛异常。"""
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P)
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P != 0:
        x = (x * _I) % _P
    if (x * x - xx) % _P != 0:
        raise LicenseError("Ed25519: 非曲线上的点")
    if x % 2 != sign:
        x = _P - x
    return x


def _encode_point(point: tuple[int, int]) -> bytes:
    x, y = point
    return struct.pack("<32s", int.to_bytes(y | ((x & 1) << 255), 32, "little"))


def _decode_point(data: bytes) -> tuple[int, int]:
    if len(data) != 32:
        raise LicenseError("Ed25519: 点长度必须是 32 字节")
    value = int.from_bytes(data, "little")
    y = value & ((1 << 255) - 1)
    sign = value >> 255
    if y >= _P:
        raise LicenseError("Ed25519: 点坐标越界")
    return _recover_x(y, sign), y


def _edwards_add(p: tuple[int, int], q: tuple[int, int]) -> tuple[int, int]:
    x1, y1 = p
    x2, y2 = q
    k = (_D * x1 * x2 * y1 * y2) % _P
    x3 = (x1 * y2 + x2 * y1) * pow(1 + k, _P - 2, _P)
    y3 = (y1 * y2 + x1 * x2) * pow(1 - k, _P - 2, _P)
    return x3 % _P, y3 % _P


_G = (
    _recover_x(4 * pow(5, _P - 2, _P) % _P, 0),
    4 * pow(5, _P - 2, _P) % _P,
)


def _scalar_mult(point: tuple[int, int], scalar: int) -> tuple[int, int]:
    result = (0, 1)  # 单位元
    addend = point
    while scalar > 0:
        if scalar & 1:
            result = _edwards_add(result, addend)
        addend = _edwards_add(addend, addend)
        scalar >>= 1
    return result


def _clamp_scalar(h: bytes) -> int:
    scalar = int.from_bytes(h[:32], "little")
    scalar &= (1 << 254) - 8
    scalar |= 1 << 254
    return scalar


def ed25519_public_from_private(seed: bytes) -> bytes:
    """由 32 字节私钥种子推导 32 字节公钥。"""
    if len(seed) != 32:
        raise LicenseError("Ed25519: 私钥种子必须是 32 字节")
    scalar = _clamp_scalar(_sha512(seed))
    return _encode_point(_scalar_mult(_G, scalar))


def ed25519_sign(seed: bytes, message: bytes) -> bytes:
    """签名，返回 64 字节。"""
    if len(seed) != 32:
        raise LicenseError("Ed25519: 私钥种子必须是 32 字节")
    digest = _sha512(seed)
    scalar = _clamp_scalar(digest)
    public = _encode_point(_scalar_mult(_G, scalar))
    r = int.from_bytes(_sha512(digest[32:] + message), "little") % _Q
    big_r = _encode_point(_scalar_mult(_G, r))
    k = int.from_bytes(_sha512(big_r + public + message), "little") % _Q
    s = (r + k * scalar) % _Q
    return big_r + int.to_bytes(s, 32, "little")


def ed25519_verify(public: bytes, message: bytes, signature: bytes) -> bool:
    """校验签名。任何异常（含畸形输入）都返回 False，不向外抛。"""
    try:
        if len(public) != 32 or len(signature) != 64:
            return False
        big_r = _decode_point(signature[:32])
        s = int.from_bytes(signature[32:], "little")
        if s >= _Q:
            return False
        public_point = _decode_point(public)
        k = int.from_bytes(_sha512(signature[:32] + public + message), "little") % _Q
        # 校验 [s]B == R + [k]A
        left = _scalar_mult(_G, s)
        right = _edwards_add(big_r, _scalar_mult(public_point, k))
        return left == right
    except Exception:
        return False


# ==========================================================================
# 机器码
# ==========================================================================
def machine_id(salt: str = "wsk-license-v1") -> str:
    """本机机器码：稳定、不可逆、不泄露原始硬件信息。

    用 主机名 + 网卡 MAC + 平台信息 做散列。注意这是**弱绑定**：懂技术的人可以改
    环境变量或换网卡来改变它，它的作用是防止卡密被随手转发，而不是防定向破解。
    """
    parts = [
        platform.node(),
        str(uuid.getnode()),
        platform.machine(),
        platform.system(),
    ]
    digest = hashlib.sha256((salt + "|" + "|".join(parts)).encode("utf-8")).digest()
    return base64.b32encode(digest[:6]).decode("ascii").rstrip("=")


# ==========================================================================
# 卡密编解码
# ==========================================================================
@dataclass
class License:
    """一张卡密的可读表示。"""

    key_id: str
    expires: int = 0  # YYYYMMDD，0 = 永久
    machine: str = ""  # 空 = 不绑定机器
    name: str = ""
    issued_at: int = field(default_factory=lambda: int(time.time()))
    version: int = 2
    signature_ok: bool = False

    @property
    def is_perpetual(self) -> bool:
        return self.expires == 0

    def expired(self, today: int | None = None) -> bool:
        if self.is_perpetual:
            return False
        now = today if today is not None else int(time.strftime("%Y%m%d"))
        return now > self.expires

    def exp_text(self) -> str:
        if self.is_perpetual:
            return "永久"
        raw = f"{self.expires:08d}"
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:]}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "key_id": self.key_id,
            "expires": self.expires,
            "machine": self.machine,
            "name": self.name,
            "issued_at": self.issued_at,
            "version": self.version,
        }


def _fit_utf8(text: str, size: int) -> bytes:
    """把字符串塞进固定字节数的字段，**不切断多字节字符**。

    曾经的 bug：直接用 ``text.encode("utf-8")[:size]`` 按字节硬截，
    中文会被从中间切开 —— "界面测试客户" 存进去再读出来变成 "界面测试客?"，
    末尾多出一个无法解码的残字节（实测复现）。

    做法：逐字符累加，一旦放下一个字符会超长就停止。
    """
    out = bytearray()
    for char in text:
        chunk = char.encode("utf-8")
        if len(out) + len(chunk) > size:
            break
        out += chunk
    return bytes(out) + b"\x00" * (size - len(out))


def _pack(license_: License) -> bytes:
    def fixed(text: str, size: int) -> bytes:
        return _fit_utf8(text, size)

    blob = (
        struct.pack("<B", license_.version)
        + struct.pack("<I", license_.expires)
        + fixed(license_.key_id, FIELD_KEY_ID)
        + fixed(license_.machine, FIELD_MACHINE)
        + fixed(license_.name, FIELD_NAME)
        + struct.pack("<I", license_.issued_at)
    )
    if len(blob) > PAYLOAD_BYTES:
        raise LicenseError("载荷过大")
    return blob + b"\x00" * (PAYLOAD_BYTES - len(blob))


def _unpack(blob: bytes) -> License:
    if len(blob) != PAYLOAD_BYTES:
        raise LicenseError(f"载荷长度错误: {len(blob)}")

    version = blob[0]
    expires = struct.unpack("<I", blob[1:5])[0]

    if version == 1:
        # 旧布局：名称 16 字节（装不下 5 个汉字，且会切断多字节字符）。
        # 保留解析以保证改动前签发的卡密仍然可用。
        key_id = blob[5:21].rstrip(b"\x00").decode("utf-8", "replace")
        machine = blob[21:29].rstrip(b"\x00").decode("utf-8", "replace")
        name = blob[29:45].rstrip(b"\x00").decode("utf-8", "replace")
        issued_at = struct.unpack("<I", blob[45:49])[0]
    elif version == 2:
        cursor = 5
        key_id = blob[cursor : cursor + FIELD_KEY_ID].rstrip(b"\x00").decode("utf-8", "replace")
        cursor += FIELD_KEY_ID
        machine = blob[cursor : cursor + FIELD_MACHINE].rstrip(b"\x00").decode("utf-8", "replace")
        cursor += FIELD_MACHINE
        name = blob[cursor : cursor + FIELD_NAME].rstrip(b"\x00").decode("utf-8", "replace")
        cursor += FIELD_NAME
        issued_at = struct.unpack("<I", blob[cursor : cursor + 4])[0]
    else:
        raise LicenseError(f"不支持的卡密版本: {version}")

    return License(
        key_id=key_id,
        expires=expires,
        machine=machine,
        name=name,
        issued_at=issued_at,
        version=version,
    )


def _b32(data: bytes) -> str:
    return base64.b32encode(data).decode("ascii").rstrip("=")


def encode_key(payload: bytes, signature: bytes) -> str:
    """把载荷+签名编成可抄写的卡密字符串。"""
    raw = _b32(payload + signature)
    groups = [raw[index : index + 5] for index in range(0, len(raw), 5)]
    return PREFIX + "-" + "-".join(groups)


def decode_key(text: str) -> tuple[bytes, bytes]:
    """解析卡密字符串，返回 (载荷, 签名)。格式错误抛 LicenseError。"""
    cleaned = "".join(ch for ch in text.strip().upper() if ch.isalnum())
    if cleaned.startswith(PREFIX):
        cleaned = cleaned[len(PREFIX) :]
    padding = "=" * (-len(cleaned) % 8)
    try:
        raw = base64.b32decode(cleaned + padding)
    except Exception as error:
        raise LicenseError(f"卡密格式无法解析: {error}") from error
    if len(raw) != KEY_BYTES:
        raise LicenseError(f"卡密长度错误: 期望 {KEY_BYTES} 字节，实得 {len(raw)}")
    return raw[:PAYLOAD_BYTES], raw[PAYLOAD_BYTES:]


# ==========================================================================
# 密钥对
# ==========================================================================
@dataclass
class KeyPair:
    private_seed: bytes
    public_key: bytes

    @property
    def private_text(self) -> str:
        return base64.b32encode(self.private_seed).decode("ascii").rstrip("=")

    @property
    def public_text(self) -> str:
        return base64.b32encode(self.public_key).decode("ascii").rstrip("=")

    @classmethod
    def from_private_text(cls, text: str) -> KeyPair:
        cleaned = "".join(ch for ch in text.strip().upper() if ch.isalnum())
        seed = base64.b32decode(cleaned + "=" * (-len(cleaned) % 8))
        if len(seed) != 32:
            raise LicenseError("私钥长度必须是 32 字节")
        return cls(seed, ed25519_public_from_private(seed))


def generate_keypair() -> KeyPair:
    seed = secrets.token_bytes(32)
    return KeyPair(seed, ed25519_public_from_private(seed))


# ==========================================================================
# 签发与校验
# ==========================================================================
def issue(
    keypair: KeyPair,
    *,
    days: int = 365,
    name: str = "",
    machine: str = "",
    key_id: str | None = None,
    perpetual: bool = False,
) -> tuple[str, License]:
    """签发一张卡密，返回 (卡密字符串, 载荷对象)。"""
    if perpetual:
        expires = 0
    else:
        expires = int(time.strftime("%Y%m%d", time.localtime(time.time() + days * 86400)))
    license_ = License(
        key_id=(key_id or secrets.token_hex(8))[:16],
        expires=expires,
        machine=machine[:8],
        name=name[:16],
        issued_at=int(time.time()),
    )
    payload = _pack(license_)
    signature = ed25519_sign(keypair.private_seed, payload)
    license_.signature_ok = True
    return encode_key(payload, signature), license_


@dataclass
class VerifyResult:
    ok: bool
    reason: str
    license: License | None = None

    def __bool__(self) -> bool:  # 允许 if verify(...)
        return self.ok


def verify(
    key_text: str,
    public_key: bytes | str,
    *,
    machine: str | None = None,
    revoke: set[str] | None = None,
    today: int | None = None,
    check_expiry: bool = True,
) -> VerifyResult:
    """校验卡密。

    返回 :class:`VerifyResult`，``ok`` 为真才放行；``reason`` 说明失败原因。
    校验顺序：格式 → 签名 → 吊销 → 到期 → 机器绑定。
    """
    if isinstance(public_key, str):
        cleaned = "".join(ch for ch in public_key.strip().upper() if ch.isalnum())
        try:
            public_key = base64.b32decode(cleaned + "=" * (-len(cleaned) % 8))
        except Exception as error:
            return VerifyResult(False, f"公钥格式错误: {error}")

    try:
        payload, signature = decode_key(key_text)
    except LicenseError as error:
        return VerifyResult(False, str(error))

    if not ed25519_verify(public_key, payload, signature):
        return VerifyResult(False, "签名无效：不是本程序签发的卡密，或内容被篡改")

    try:
        license_ = _unpack(payload)
    except LicenseError as error:
        return VerifyResult(False, str(error))

    license_.signature_ok = True

    if revoke and license_.key_id in revoke:
        return VerifyResult(False, f"该卡密已被吊销 (id={license_.key_id})", license_)

    if check_expiry and license_.expired(today):
        return VerifyResult(False, f"卡密已过期（有效期至 {license_.exp_text()}）", license_)

    if license_.machine:
        current = machine if machine is not None else machine_id()
        if current[:8] != license_.machine:
            return VerifyResult(
                False,
                f"卡密已绑定其它机器（本机 {current[:8]}，卡密 {license_.machine}）",
                license_,
            )

    return VerifyResult(True, "校验通过", license_)


# ==========================================================================
# 台账（可选，用于签发记录 / 吊销）
# ==========================================================================
def load_revocations(path: str) -> set[str]:
    """从台账文件读取已吊销的 key_id 集合。"""
    if not os.path.exists(path):
        return set()
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception:
        return set()
    entries = data.get("keys", data if isinstance(data, list) else [])
    return {str(item.get("key_id")) for item in entries if isinstance(item, dict) and item.get("revoked")}


def describe(license_: License) -> str:
    """人类可读的卡密摘要。"""
    rows = [
        f"  卡密编号 : {license_.key_id}",
        f"  授权对象 : {license_.name or '(未填写)'}",
        f"  有效期至 : {license_.exp_text()}",
        f"  机器绑定 : {license_.machine or '(未绑定)'}",
        f"  签发时间 : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(license_.issued_at))}",
    ]
    return "\n".join(rows)
