"""测试交互式输入卡密的完整流程（模拟用户第一次运行、粘贴卡密）。

同时验证：输入错误卡密会提示重试、输入 q 会退出、成功后卡密被本机记住。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
failures = 0

# 关键：把 LOCALAPPDATA 指到一个临时目录，让被测程序把"记住的卡密"写到这里，
# 而不是用户真实的 %LOCALAPPDATA%\wsk-license\token.json。
# 之前这里直接删除用户真实缓存，既污染环境、又让别的测试受牵连。
import tempfile  # noqa: E402

ISOLATED = tempfile.mkdtemp(prefix="wsk-test-")
TEST_ENV = dict(os.environ, LOCALAPPDATA=ISOLATED, SELFTEST_NO_PAUSE="1", PYTHONIOENCODING="utf-8")
store = os.path.join(ISOLATED, "wsk-license", "token.json")


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<42} {detail}")
    if not ok:
        failures += 1


def run_interactive(args: list[str], stdin_text: str) -> tuple[int, str]:
    # 自动补 --target 测试用替身.py，与 授权验证.py 里配置的目标程序解耦。
    if args and args[0] == "授权验证.py" and "--target" not in args:
        args = [args[0], "--target", "测试用替身.py", *args[1:]]
    done = subprocess.run(
        [PY, *args],
        cwd=HERE,
        input=stdin_text,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
        env=TEST_ENV,
    )
    return done.returncode, (done.stdout or "") + (done.stderr or "")


def issue(name: str) -> str:
    done = subprocess.run(
        [PY, "签发工具.py", "issue", "--days", "30", "--name", name],
        cwd=HERE,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
    )
    for line in done.stdout.splitlines():
        if line.strip().startswith("WSK1-"):
            return line.strip()
    return ""


print("=" * 78)
print("交互式流程测试")
print("=" * 78)
print(f"  (使用隔离的存储目录，不动你真实的卡密缓存: {ISOLATED})")

# 隔离目录本来就是空的，不需要"清除本机缓存"

# ---- 1. 输入 q 退出 -------------------------------------------------
code, out = run_interactive(["授权验证.py"], "q\n")
check("输入 q 退出", code != 0 and "需要卡密" in out, f"exit={code}")
check("显示了机器码", "本机机器码" in out)

# ---- 2. 先输错再输对 -------------------------------------------------
good_key = issue("交互测试客户")
check("签发出测试卡密", bool(good_key), f"{good_key[:24]}...")

code, out = run_interactive(["授权验证.py"], "WSK1-BADKEY-XXXXX\n" + good_key + "\n")
check("错误卡密提示重试", "请核对后重试" in out or "卡密无效" in out)
check("重试后正确卡密放行", code == 0 and "被保护程序已启动" in out, f"exit={code}")

# ---- 3. 卡密被记住：第二次运行无需再输入 -----------------------------
check("本机已保存卡密", os.path.exists(store))
if os.path.exists(store):
    saved = json.load(open(store, encoding="utf-8")).get("key", "")
    check("保存的就是那张卡密", saved.strip() == good_key, f"{saved[:24]}...")

code, out = run_interactive(["授权验证.py"], "")
check("第二次无需输入即放行", code == 0 and "被保护程序已启动" in out, f"exit={code}")

# ---- 4. --forget 清除后又要重新输入 ----------------------------------
code, out = run_interactive(["授权验证.py", "--forget"], "")
check("--forget 清除成功", code == 0 and "已清除" in out, f"exit={code}")
check("缓存文件确实删掉", not os.path.exists(store))

code, out = run_interactive(["授权验证.py"], "q\n")
check("清除后回到需要卡密状态", "需要卡密" in out)

# ---- 5. 超过最大尝试次数 --------------------------------------------
wrong = "\n".join(["WSK1-NOPE-1", "WSK1-NOPE-2", "WSK1-NOPE-3", "WSK1-NOPE-4", "WSK1-NOPE-5", ""])
code, out = run_interactive(["授权验证.py"], wrong + "\n")
check("多次失败后退出", code != 0 and "尝试次数过多" in out, f"exit={code}")

# 收尾：删掉隔离目录（真实缓存本来就没被动过）
import shutil  # noqa: E402

shutil.rmtree(ISOLATED, ignore_errors=True)

print()
print("=" * 78)
if failures:
    print(f"  {failures} 项失败")
    raise SystemExit(1)
print("  交互式流程全部通过 ✔")
print("=" * 78)
raise SystemExit(0)
