"""测试用的「被保护程序」替身：证明 gate 放行后确实能启动目标程序。

注意这里也重配置了 UTF-8 —— 中文 Windows 上不这么做，中文输出会变成 GBK 字节，
调用方按 UTF-8 解码时就成了乱码（我第一版就踩了这个坑）。
"""

from __future__ import annotations

import sys

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

print("  >>> 被保护程序已启动（模拟你的业务程序）")
print(f"  >>> 参数: {sys.argv[1:]}")
print("  >>> 退出码将是 0")
raise SystemExit(0)
