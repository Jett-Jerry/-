"""打包脚本：生成两个 exe。

    python 打包.py            两个都打
    python 打包.py 界面        只打用户侧的授权验证界面
    python 打包.py 签发        只打发行方用的签发工具

产物在 dist_exe\\ 下：

* ``授权验证.exe``   给用户。双击打开图形界面，校验通过后运行被保护程序。
                     公钥在打包时已嵌入，**不含私钥**，可放心分发。
* ``签发工具.exe``   给你自己。**必须与 私钥_保管好.txt 放在同一目录**，
                     私钥不打包进去（打进去就等于把发卡权送给每个拿到 exe 的人）。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, "dist_exe")
BUILD = os.path.join(HERE, "build_exe")

TARGETS = {
    "界面": {
        "script": "授权验证_界面.py",
        "name": "授权验证",
        "windowed": True,
        "hidden": [
            # 项目自己的模块（中文名，静态分析不一定跟得到）
            "卡密核心", "冻结环境",
            # ↓ 这些在代码里是**函数内/条件内**导入的，PyInstaller 静态分析看不到。
            #   实测漏掉会让 exe 一启动就崩；窗口程序没有控制台 → 表现为"闪退"。
            "secrets", "uuid", "platform",
            "tkinter", "tkinter.ttk", "tkinter.messagebox", "tkinter.font",
            "subprocess", "datetime",
            "time", "base64", "hashlib", "hmac", "struct", "json",
        ],
        "required": ["tkinter", "卡密核心", "冻结环境", "secrets", "uuid", "platform", "hmac"],
    },
    "签发": {
        "script": "签发工具.py",
        "name": "签发工具",
        "windowed": False,
        "hidden": [
            "卡密核心", "批量签发", "冻结环境",
            "secrets", "uuid", "platform", "csv", "random", "shutil",
            "time", "base64", "hashlib", "hmac", "struct", "json",
        ],
        "required": ["卡密核心", "批量签发", "冻结环境", "secrets", "uuid", "platform", "hmac"],
    },
}


def verify_exe(exe: str, key: str, spec: dict) -> tuple[bool, str]:
    """把刚打好的 exe 复制到临时目录实际跑一遍，确认它能启动。

    打包成功 ≠ 能运行：PyInstaller 不会报"少打包了某个模块"，
    而窗口程序又没有控制台，缺模块时就是无声闪退。所以在构建阶段就把关。
    """
    import tempfile

    deploy = tempfile.mkdtemp(prefix=f"wsk-verify-{key}-")
    target = os.path.join(deploy, os.path.basename(exe))
    shutil.copy2(exe, target)
    # 界面版需要一个被保护程序在旁边，否则自检会说"找不到"
    shutil.copy2(os.path.join(HERE, "测试用替身.py"), os.path.join(deploy, "环境自测.py"))

    env = {k: v for k, v in os.environ.items()
           if k.upper() not in ("PYTHONPATH", "PYTHONHOME")}
    env["LOCALAPPDATA"] = tempfile.mkdtemp(prefix="wsk-verify-store-")

    args = [target, "--check"]
    if key == "签发":
        args = [target, "list"]

    try:
        done = subprocess.run(
            args, cwd=deploy, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=300, env=env,
        )
    except Exception as error:  # noqa: BLE001
        return False, f"启动自检异常: {error}"

    output = (done.stdout or "") + (done.stderr or "")

    # 缺模块的特征：ModuleNotFoundError
    if "ModuleNotFoundError" in output or "No module named" in output:
        missing = [
            line.strip() for line in output.splitlines()
            if "No module named" in line
        ]
        return False, (f"exe 缺少模块，运行会闪退！请把它们加进 打包.py 的 hidden 列表:\n"
                       + "\n".join(f"      {line}" for line in missing[:6]))

    if done.returncode not in (0, 1) and key == "界面":
        return False, f"exe --check 退出码异常 {done.returncode}:\n{output.strip()[-400:]}"

    keeps_running = "界面构建: OK" in output
    if key == "界面" and not keeps_running:
        return False, f"exe 自检未通过:\n{output.strip()[-400:]}"

    shutil.rmtree(deploy, ignore_errors=True)
    return True, "exe 可正常启动并自检通过"


def build(key: str) -> tuple[bool, str]:
    spec = TARGETS[key]
    script = os.path.join(HERE, spec["script"])
    if not os.path.exists(script):
        return False, f"找不到源文件 {script}"

    command = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm", "--clean", "--onefile",
        "--name", spec["name"],
        "--distpath", DIST,
        "--workpath", os.path.join(BUILD, key),
        "--specpath", BUILD,
    ]
    if spec["windowed"]:
        command.append("--windowed")          # 不弹黑框
    for module in spec["hidden"]:
        command += ["--hidden-import", module]
    command.append(script)

    print(f"\n{'=' * 74}")
    print(f"打包 {key}：{spec['script']} -> {spec['name']}.exe")
    print("=" * 74)
    started = time.perf_counter()
    done = subprocess.run(
        command, cwd=HERE, capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=1800,
    )
    elapsed = time.perf_counter() - started
    print(f"  PyInstaller 用时 {elapsed:.0f} 秒，exit={done.returncode}")

    exe = os.path.join(DIST, spec["name"] + ".exe")
    if done.returncode != 0 or not os.path.exists(exe):
        print("  --- 失败，末尾输出 ---")
        for line in (done.stdout or "").splitlines()[-25:]:
            print(f"    {line.strip()}")
        for line in (done.stderr or "").splitlines()[-15:]:
            print(f"  ! {line.strip()}")
        return False, f"{key} 打包失败"

    size = os.path.getsize(exe) / 1024 / 1024
    print(f"  产物: {exe}  ({size:.1f} MB)")

    # 打包后立刻自检：把 exe 复制到临时目录跑 --check，确认它真的能启动。
    # 这一步是"闪退"问题的守门员 —— 打包成功不等于能运行。
    ok, detail = verify_exe(exe, key, spec)
    if not ok:
        return False, detail
    print(f"  启动自检: {detail}")
    return True, exe


def main() -> int:
    wanted = sys.argv[1] if len(sys.argv) > 1 else ""
    keys = [k for k in TARGETS if not wanted or wanted in k]
    if not keys:
        print(f"没有匹配的目标: {wanted}（可用: {' / '.join(TARGETS)}）")
        return 2

    os.makedirs(DIST, exist_ok=True)
    os.makedirs(BUILD, exist_ok=True)

    print("提示：用户侧 exe 的公钥在打包时嵌入。若刚换过密钥，请先运行")
    print("      python _embed_gui.py   再打包，否则新卡密会校验失败。")

    results = {key: build(key) for key in keys}

    print(f"\n{'=' * 74}")
    print("结果")
    print("=" * 74)
    ok = True
    for key, (success, info) in results.items():
        print(f"  {'OK  ' if success else 'FAIL'} {key:<6} {info}")
        ok = ok and success

    if ok:
        print(f"\n产物目录: {DIST}")
        print("分发时给用户:")
        print("  授权验证.exe        ← 用户双击运行")
        print("  被保护的程序         ← 例如 环境自测.py 或你自己的程序")
        print("  注：用户不需要装 Python")
        print("\n自己保留（切勿外发）:")
        print("  签发工具.exe + 私钥_保管好.txt + 台账.json")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
