"""运行环境适配：让同一份代码在「源码运行」和「PyInstaller 打包的 exe」下都能找到文件。

打包后有个经典陷阱：``__file__`` 指向的是**临时解包目录**（onefile 模式会把东西解到
``%TEMP%\\_MEIxxxxxx``），把用户数据写在那里会在程序退出时被删掉。所以要区分：

* ``程序目录``  —— exe 所在目录（打包后）或源码目录（未打包），**数据文件放这里**
* ``资源目录``  —— 解包目录（打包后）或源码目录（未打包），**只读资源放这里**
"""

from __future__ import annotations

import os
import sys

FROZEN = bool(getattr(sys, "frozen", False))


def program_dir() -> str:
    """程序所在目录：打包后是 exe 所在目录，未打包是源码所在目录。

    用户数据（私钥、台账、公钥、导出的卡密表）都相对这个目录找，
    这样打包后不会写进临时解包目录。
    """
    if FROZEN:
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_dir() -> str:
    """只读资源目录：打包后是 PyInstaller 的解包目录，未打包是源码目录。"""
    if FROZEN:
        return getattr(sys, "_MEIPASS", program_dir())
    return os.path.dirname(os.path.abspath(__file__))


def find_file(name: str, extra_dirs: list[str] | None = None) -> str | None:
    """在若干候选目录里找文件，返回第一个存在的绝对路径。

    搜索顺序：程序目录 → 解包目录 → 上一级目录 → 当前工作目录 → extra_dirs。
    这样同一个程序放在 licensing 里能跑，单独拷到别处也能跑。
    """
    candidates: list[str] = []
    base = program_dir()
    for directory in [base, resource_dir(), os.path.dirname(base), os.getcwd(), *(extra_dirs or [])]:
        if directory:
            candidates.append(os.path.join(directory, name))
    for path in candidates:
        if os.path.exists(path):
            return os.path.abspath(path)
    return None


def find_script(name: str) -> str | None:
    """按名字找 .py 脚本（源码运行时用；打包后脚本被并进 exe，一般找不到）。"""
    return find_file(name)


def describe() -> str:
    """给界面/日志用的一句话环境说明。"""
    if FROZEN:
        return f"打包运行（exe 目录 {program_dir()}）"
    return f"源码运行（{program_dir()}）"
