"""批量签发卡密，并导出成 Excel 能直接打开的 CSV / JSONL。

被 签发工具.py 的 ``batch`` 子命令使用，也可单独调用：

    from 批量签发 import batch_issue
    summary = batch_issue(count=100, days=365, out_path="卡密.csv")

导出格式
--------
* ``.csv``   —— UTF-8 带 BOM，双击直接用 Excel 打开且中文不乱码
* ``.jsonl`` —— 每行一个 JSON，便于程序二次处理
* ``.txt``   —— 每行一张卡密，便于直接发给用户
"""

from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any

from 卡密核心 import KeyPair, License, issue

# 默认前缀，避免空名字时整列都是空的
DEFAULT_NAME_FORMAT = "客户{n:03d}"


@dataclass
class BatchResult:
    """批量签发结果。"""

    licenses: list[tuple[str, License]] = field(default_factory=list)
    written: list[str] = field(default_factory=list)
    seconds: float = 0.0

    @property
    def count(self) -> int:
        return len(self.licenses)

    def summary(self) -> str:
        names = {lic.name for _, lic in self.licenses}
        expires = {lic.exp_text() for _, lic in self.licenses}
        machines = {lic.machine for _, lic in self.licenses}
        rows = [
            f"签发数量 : {self.count}",
            f"有效期至 : {', '.join(sorted(expires)) if len(expires) < 4 else '(多种)'}",
            f"机器绑定 : {machines.pop() if len(machines) == 1 and machines else '(各不相同)'}",
            f"名称示例 : {', '.join(sorted(names)[:3])}{' …' if len(names) > 3 else ''}",
            f"耗时     : {self.seconds:.2f} 秒",
        ]
        return "\n".join(rows)


def batch_issue(
    keypair: KeyPair,
    *,
    count: int,
    days: int | None = 365,
    perpetual: bool = False,
    name_format: str = DEFAULT_NAME_FORMAT,
    machine: str = "",
    out_path: str = "",
    fmt: str = "",
) -> BatchResult:
    """签发 ``count`` 张卡密。

    ``name_format`` 支持两个占位符：
      * ``{n}``    序号，从 1 开始（可写 ``{n:03d}`` 补零）
      * ``{total}``总数
    """
    if count <= 0:
        raise ValueError("数量必须大于 0")
    if count > 100_000:
        raise ValueError("一次最多签发 100000 张，请分批")

    started = time.perf_counter()
    result = BatchResult()

    for index in range(1, count + 1):
        try:
            name = name_format.format(n=index, total=count)
        except (KeyError, IndexError, ValueError):
            name = f"{name_format}{index}"
        key, license_ = issue(
            keypair,
            days=days if days is not None else 365,
            name=name,
            machine=machine,
            perpetual=perpetual,
        )
        result.licenses.append((key, license_))

    result.seconds = time.perf_counter() - started
    if out_path:
        result.written = export(result, out_path, fmt)
    return result


def export(result: BatchResult, out_path: str, fmt: str = "") -> list[str]:
    """把签发结果写成文件，返回实际写出的路径列表。"""
    base, ext = os.path.splitext(out_path)
    fmt = (fmt or ext.lstrip(".") or "csv").lower()

    written: list[str] = []
    parent = os.path.dirname(os.path.abspath(out_path))
    os.makedirs(parent, exist_ok=True)

    if fmt in ("csv", "xlsx", "excel"):
        # 用 .csv 承载（Excel 可直接打开）；utf-8-sig 保证中文不乱码
        path = out_path if ext.lower() == ".csv" else base + ".csv"
        with open(path, "w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["序号", "卡密编号", "授权对象", "有效期至", "机器绑定", "状态", "卡密"])
            today = int(time.strftime("%Y%m%d"))
            for index, (key, license_) in enumerate(result.licenses, 1):
                if license_.expired(today):
                    status = "已过期"
                else:
                    status = "有效"
                writer.writerow([
                    index,
                    license_.key_id,
                    license_.name,
                    license_.exp_text(),
                    license_.machine or "",
                    status,
                    key,
                ])
        written.append(path)

    elif fmt in ("jsonl", "json"):
        path = out_path if ext.lower() in (".jsonl", ".json") else base + ".jsonl"
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            for index, (key, license_) in enumerate(result.licenses, 1):
                handle.write(json.dumps(
                    {"序号": index, "卡密": key, **license_.to_dict(),
                     "有效期至": license_.exp_text()},
                    ensure_ascii=False,
                ) + "\n")
        written.append(path)

    elif fmt in ("txt", "text"):
        path = out_path if ext.lower() == ".txt" else base + ".txt"
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            for key, _ in result.licenses:
                handle.write(key + "\n")
        written.append(path)

    else:
        raise ValueError(f"不支持的导出格式: {fmt}（可用 csv / jsonl / txt）")

    return written


def append_to_ledger(result: BatchResult, ledger: dict[str, Any]) -> dict[str, Any]:
    """把批量结果并入台账结构（调用方负责保存）。"""
    entries = ledger.setdefault("keys", [])
    for key, license_ in result.licenses:
        entries.append({
            "key_id": license_.key_id,
            "name": license_.name,
            "expires": license_.expires,
            "machine": license_.machine,
            "issued_at": license_.issued_at,
            "issued_at_text": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(license_.issued_at)),
            "key": key,
            "revoked": False,
            "batch": True,
        })
    return ledger
