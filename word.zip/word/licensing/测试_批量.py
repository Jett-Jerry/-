"""验证批量签发产出的卡密文件是否可用。"""

from __future__ import annotations

import csv
import json
import os
import random
import subprocess
import sys
import tempfile

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
failures = 0

ISOLATED = tempfile.mkdtemp(prefix="wsk-batch-")
ENV = dict(os.environ, LOCALAPPDATA=ISOLATED, SELFTEST_NO_PAUSE="1", PYTHONIOENCODING="utf-8")


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<40} {detail}")
    if not ok:
        failures += 1


print("=" * 76)
print("批量签发产出验证")
print("=" * 76)

# ---- 0. 自己生成样本（不要依赖别人留下的文件！）----------------------
# 早先这里直接读 测试卡密.csv，结果它是我手工跑出来的旧文件，
# 与后来的台账对不上，导致"缺失 20 张"的假失败。测试必须自包含。
with open(os.path.join(HERE, "台账.json"), encoding="utf-8") as handle:
    ledger_before = len(json.load(handle)["keys"])

gen = subprocess.run(
    [sys.executable, os.path.join(HERE, "签发工具.py"), "batch",
     "--count", "20", "--days", "365", "--name", "代理商A-{n:03d}",
     "--out", os.path.join(HERE, "测试卡密.csv")],
    cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace", env=ENV,
)
check("批量签发命令执行成功", gen.returncode == 0, f"exit={gen.returncode}")
if gen.returncode != 0:
    print((gen.stdout or "")[-500:])
    raise SystemExit(1)

with open(os.path.join(HERE, "台账.json"), encoding="utf-8") as handle:
    ledger_after = len(json.load(handle)["keys"])
check("本次签发新增了 20 条台账记录", ledger_after - ledger_before == 20,
      f"{ledger_before} -> {ledger_after}")

# ---- 1. CSV 结构 ----
path = os.path.join(HERE, "测试卡密.csv")
check("CSV 文件存在", os.path.exists(path), f"{os.path.getsize(path)} bytes")

with open(path, encoding="utf-8-sig", newline="") as handle:
    rows = list(csv.reader(handle))
header, data = rows[0], rows[1:]
check("表头正确", header[:3] == ["序号", "卡密编号", "授权对象"], str(header[:4]))
check("数据行数 = 20", len(data) == 20, f"{len(data)} 行")
check("列数一致", all(len(r) == len(header) for r in data))
check("序号连续", [r[0] for r in data] == [str(i) for i in range(1, 21)])
check("名称按模板生成", data[0][2] == "代理商A-001" and data[19][2] == "代理商A-020",
      f"{data[0][2]} … {data[19][2]}")
check("卡密列都是 WSK1 开头", all(r[6].startswith("WSK1-") for r in data))
check("卡密互不相同", len({r[6] for r in data}) == 20)

# ---- 2. UTF-8 BOM（Excel 打开不乱码的关键）----
raw = open(path, "rb").read(3)
check("带 UTF-8 BOM（Excel 中文不乱码）", raw == b"\xef\xbb\xbf", repr(raw))

# ---- 3. 抽 5 张真的拿去校验 ----
from 授权验证_界面 import embedded_public_key
from 卡密核心 import verify

sample = random.sample(data, 5)
all_ok = True
for row in sample:
    result = verify(row[6], embedded_public_key(), machine=str(row[4] or ""))
    if not result.ok:
        all_ok = False
        print(f"      失败: {row[2]} -> {result.reason}")
check("随机抽 5 张全部校验通过", all_ok)

print(f"  抽查明细: {', '.join(r[2] for r in sample)}")

# ---- 4. 台账里有没有这 20 张 ----
import json

ledger = json.load(open(os.path.join(HERE, "台账.json"), encoding="utf-8"))
ledger_keys = {e.get("key") for e in ledger.get("keys", [])}
csv_keys = {row[6] for row in data}
missing = csv_keys - ledger_keys

# 失败时把关键信息打出来，别只报"缺失 N 张"
if missing:
    print(f"      诊断: 台账条数={len(ledger_keys)}  CSV条数={len(csv_keys)}  缺失={len(missing)}")
    print(f"      诊断: 台账文件={os.path.join(HERE, '台账.json')}")
    print(f"      诊断: CSV 首张={sorted(csv_keys)[0][:46]}…")
    sample = sorted(ledger_keys)[0] if ledger_keys else "(台账为空)"
    print(f"      诊断: 台账首张={str(sample)[:46]}…")

check("20 张卡密全部写入台账", not missing, f"缺失 {len(missing)} 张")
check("台账记录带 batch 标记",
      all(e.get("batch") for e in ledger["keys"] if e.get("key") in csv_keys))

# ---- 5. 其他导出格式 ----
for fmt, ext, needle in [("jsonl", ".jsonl", '"卡密"'), ("txt", ".txt", "WSK1-")]:
    out = os.path.join(HERE, f".test_export{ext}")
    done = subprocess.run(
        [sys.executable, os.path.join(HERE, "签发工具.py"), "batch",
         "--count", "3", "--days", "10", "--name", "导出测试{n}",
         "--out", out, "--format", fmt],
        cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace", env=ENV,
    )
    exists = os.path.exists(out)
    text = open(out, encoding="utf-8").read() if exists else ""
    check(f"{fmt} 导出可用", done.returncode == 0 and exists and needle in text,
          f"exit={done.returncode}, {len(text)} 字符")
    if exists:
        os.remove(out)

# ---- 6. 错误处理 ----
done = subprocess.run(
    [sys.executable, os.path.join(HERE, "签发工具.py"), "batch", "--count", "0"],
    cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace", env=ENV,
)
check("数量 0 被拒绝", done.returncode != 0 and "必须大于" in (done.stdout + done.stderr),
      f"exit={done.returncode}")

# ---- 7. 台账损坏时不能静默清空（数据安全回归）----
# 曾经的实现：load_ledger() 读失败就返回 {"keys": []}，调用方紧接着保存，
# 于是整个台账被覆盖成只剩新记录 —— 真实的数据丢失路径。
import shutil  # noqa: E402

ledger_file = os.path.join(HERE, "台账.json")
backup = ledger_file + ".pytest-backup"
shutil.copy2(ledger_file, backup)
before_count = len(json.load(open(ledger_file, encoding="utf-8"))["keys"])
try:
    with open(ledger_file, "w", encoding="utf-8") as handle:
        handle.write("{ 这不是合法 JSON")
    done = subprocess.run(
        [sys.executable, os.path.join(HERE, "签发工具.py"), "batch", "--count", "2",
         "--out", os.path.join(HERE, ".t7.csv")],
        cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace", env=ENV,
    )
    text = (done.stdout or "") + (done.stderr or "")
    check("台账损坏时命令失败而非清空", done.returncode != 0, f"exit={done.returncode}")
    check("给出可读的错误原因", "读取台账失败" in text, text.strip().splitlines()[-1][:60] if text.strip() else "")
    still_broken = open(ledger_file, encoding="utf-8").read()
    check("损坏内容未被覆盖", "这不是合法 JSON" in still_broken)
finally:
    shutil.move(backup, ledger_file)
    for leftover in (".t7.csv",):
        path = os.path.join(HERE, leftover)
        if os.path.exists(path):
            os.remove(path)

after_count = len(json.load(open(ledger_file, encoding="utf-8"))["keys"])
check("恢复后台账条数不变", after_count == before_count, f"{before_count} -> {after_count}")

# ---- 8. 原子写入不残留临时文件 ----
check("无残留 .tmp 文件", not os.path.exists(ledger_file + ".tmp"))

print()
print("=" * 76)
print(f"  {'全部通过 ✔' if not failures else str(failures) + ' 项失败'}")
print("=" * 76)
raise SystemExit(1 if failures else 0)
