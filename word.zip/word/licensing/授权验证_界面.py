"""图形界面版授权验证：粘贴卡密 → 校验 → 放行。

只用标准库（tkinter 内置），不依赖任何第三方包。
命令行版是 授权验证.py；本文件是同一套校验逻辑的图形外壳。

    python 授权验证_界面.py            打开窗口
    python 授权验证_界面.py --key XXX  带卡密直接打开并自动校验（自动化用）

界面上的配置常量（公钥/吊销名单/目标程序）由 _embed_gui.py 从
授权验证.py 自动抄过来，因此两个入口永远共用同一份授权信息。
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time          # _log() 与剩余天数计算都要用
import tkinter as tk
from tkinter import messagebox, ttk

# --------------------------------------------------------------------------
# 编码：窗口模式（pythonw）下 stdout 可能是 None，必须容错
# --------------------------------------------------------------------------
for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from 卡密核心 import LicenseError, machine_id, verify  # noqa: E402
from 冻结环境 import FROZEN, find_file, program_dir  # noqa: E402

# ==========================================================================
# 配置区（由 _embed_gui.py 自动同步，也可手工修改）
# ==========================================================================
PUBLIC_KEY_TEXT = """
DIJL6L7DT4QK6IKTPTEZJDAV6FWEMSUFRLOG4LXZB6DT674WFOUA
"""
REVOKED: set[str] = set()
TARGET_PROGRAM = "../\u73af\u5883\u81ea\u6d4b.py"
TITLE = "软件授权验证"
SUBTITLE = "请输入卡密以继续使用"
WINDOW_SIZE = "560x520"
# ==========================================================================

STORE_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "wsk-license")
STORE_PATH = os.path.join(STORE_DIR, "token.json")

# 配色
COLOR_OK = "#1a7f37"
COLOR_BAD = "#c0392b"
COLOR_WARN = "#b7791f"
COLOR_MUTED = "#666666"


# --------------------------------------------------------------------------
# 配置辅助
# --------------------------------------------------------------------------
def embedded_public_key() -> str:
    return "".join(PUBLIC_KEY_TEXT.split())


def config_ready() -> tuple[bool, str]:
    key = embedded_public_key()
    if not key or "REPLACE_ME" in key:
        return False, "本程序尚未嵌入公钥，请发行方运行 签发工具.py public 后同步配置。"
    return True, ""


def load_stored_key() -> str:
    import json

    try:
        with open(STORE_PATH, encoding="utf-8") as handle:
            return str(json.load(handle).get("key", ""))
    except Exception:
        return ""


def save_stored_key(key: str) -> str:
    import json
    import time

    try:
        os.makedirs(STORE_DIR, exist_ok=True)
        with open(STORE_PATH, "w", encoding="utf-8") as handle:
            json.dump({"key": key, "saved_at": int(time.time())}, handle)
        if os.name != "nt":
            os.chmod(STORE_PATH, 0o600)
        return STORE_PATH
    except Exception as error:  # noqa: BLE001
        return f"保存失败: {error}"


def resolve_target(override: str = "") -> str | None:
    """定位被保护的程序。

    打包成 exe 后脚本常放在 exe 旁边而不是解包目录，所以搜索顺序是：

    1. ``--target`` 指定的路径（最高优先，便于现场调试）
    2. 程序目录 / 上一级目录 下的原样路径（兼容源码目录里写 ``../环境自测.py``）
    3. 程序目录 / 上一级目录 下只取文件名（兼容"exe 和程序放同一目录"，
       这是打包分发的常见布局 —— 实测踩过：写死 ``../环境自测.py`` 时，
       程序明明在同一目录却报找不到）
    4. 脚本目录、当前工作目录
    """
    if override:
        if os.path.isabs(override):
            return override if os.path.exists(override) else None
        for base in (program_dir(), os.getcwd(), HERE):
            candidate = os.path.join(base, override)
            if os.path.exists(candidate):
                return os.path.abspath(candidate)
        return None

    if os.path.isabs(TARGET_PROGRAM):
        return TARGET_PROGRAM if os.path.exists(TARGET_PROGRAM) else None

    base = program_dir()
    basename = os.path.basename(TARGET_PROGRAM)
    candidates = [
        os.path.join(base, TARGET_PROGRAM),
        os.path.abspath(os.path.join(base, "..", TARGET_PROGRAM)),
        os.path.join(base, basename),
        os.path.abspath(os.path.join(base, "..", basename)),
        os.path.join(HERE, TARGET_PROGRAM),
        os.path.abspath(os.path.join(HERE, "..", TARGET_PROGRAM)),
        os.path.join(os.getcwd(), basename),
    ]
    for candidate in candidates:
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    return None


# --------------------------------------------------------------------------
# 界面
# --------------------------------------------------------------------------
class LicenseWindow:
    def __init__(self, root: tk.Tk, preset_key: str = "") -> None:
        self.root = root
        self.license = None
        self.result = None
        self.verified_key = ""

        root.title(TITLE)
        root.geometry(WINDOW_SIZE)
        root.minsize(520, 480)
        try:
            root.call("tk", "scaling", 1.25)
        except Exception:
            pass

        self._build(preset_key)
        self.refresh_machine_id()
        self._autofill(preset_key)

    # -- 构建 ----------------------------------------------------------
    def _build(self, preset_key: str) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except Exception:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 15, "bold"))
        style.configure("Sub.TLabel", foreground=COLOR_MUTED)
        style.configure("Status.TLabel", font=("Microsoft YaHei UI", 11, "bold"))
        style.configure("Mono.TLabel", font=("Consolas", 10))
        style.configure("Big.TButton", font=("Microsoft YaHei UI", 10))

        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text=TITLE, style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text=SUBTITLE, style="Sub.TLabel").pack(anchor="w", pady=(2, 12))

        # 卡密输入
        key_box = ttk.LabelFrame(outer, text=" 卡密 ", padding=10)
        key_box.pack(fill="x")

        self.key_text = tk.Text(key_box, height=4, wrap="char", font=("Consolas", 10),
                                relief="solid", borderwidth=1)
        self.key_text.pack(fill="x")
        if preset_key:
            self.key_text.insert("1.0", preset_key)

        row = ttk.Frame(key_box)
        row.pack(fill="x", pady=(8, 0))
        self.btn_verify = ttk.Button(row, text="校验卡密", command=self.on_verify,
                                     style="Big.TButton")
        self.btn_verify.pack(side="left")
        ttk.Button(row, text="从剪贴板粘贴", command=self.on_paste).pack(side="left", padx=6)
        ttk.Button(row, text="清空", command=self.on_clear).pack(side="left")
        self.remember = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text="记住卡密", variable=self.remember).pack(side="right")

        # 状态
        status_box = ttk.Frame(outer)
        status_box.pack(fill="x", pady=(12, 0))
        self.status = ttk.Label(status_box, text="等待校验…", style="Status.TLabel",
                                foreground=COLOR_MUTED)
        self.status.pack(anchor="w")
        self.detail = ttk.Label(status_box, text="", style="Sub.TLabel", wraplength=500,
                                justify="left")
        self.detail.pack(anchor="w", pady=(2, 0))

        # 续期进度条（剩余有效期可视化）
        self.progress = ttk.Progressbar(status_box, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(8, 0))

        # 机器码
        mid_box = ttk.LabelFrame(outer, text=" 本机机器码 ", padding=10)
        mid_box.pack(fill="x", pady=(12, 0))
        mid_row = ttk.Frame(mid_box)
        mid_row.pack(fill="x")
        self.machine_label = ttk.Label(mid_row, text="", style="Mono.TLabel")
        self.machine_label.pack(side="left")
        ttk.Button(mid_row, text="复制", width=6, command=self.on_copy_machine).pack(side="right")
        ttk.Label(mid_box, text="购买或续期时把这个码发给发行方，可绑定到本机。",
                  style="Sub.TLabel", wraplength=500, justify="left").pack(anchor="w", pady=(4, 0))

        # 授权信息
        info_box = ttk.LabelFrame(outer, text=" 授权信息 ", padding=10)
        info_box.pack(fill="both", expand=True, pady=(12, 0))
        self.info_text = tk.Text(info_box, height=6, wrap="word", relief="flat",
                                 background=self.root.cget("background"),
                                 font=("Microsoft YaHei UI", 10))
        self.info_text.pack(fill="both", expand=True)
        self.info_text.configure(state="disabled")

        # 底部按钮
        bottom = ttk.Frame(outer)
        bottom.pack(fill="x", pady=(12, 0))
        self.btn_run = ttk.Button(bottom, text="运行程序", command=self.on_run,
                                  state="disabled", style="Big.TButton")
        self.btn_run.pack(side="left")
        ttk.Button(bottom, text="退出", command=self.root.destroy).pack(side="right")

        self.key_text.bind("<Control-Return>", lambda _event: self.on_verify())
        self.root.bind("<F5>", lambda _event: self.on_verify())

    # -- 小工具 --------------------------------------------------------
    def current_key(self) -> str:
        return self.key_text.get("1.0", "end").strip()

    def set_status(self, text: str, color: str, detail: str = "") -> None:
        self.status.configure(text=text, foreground=color)
        self.detail.configure(text=detail)

    def set_info(self, lines: list[str]) -> None:
        self.info_text.configure(state="normal")
        self.info_text.delete("1.0", "end")
        self.info_text.insert("1.0", "\n".join(lines))
        self.info_text.configure(state="disabled")

    def refresh_machine_id(self) -> None:
        try:
            self.machine_label.configure(text=machine_id())
        except Exception as error:  # noqa: BLE001
            self.machine_label.configure(text=f"(取机器码失败: {error})")

    # -- 事件 ----------------------------------------------------------
    def _autofill(self, preset_key: str) -> None:
        if preset_key:
            self.root.after(300, self.on_verify)
            return
        ready, why = config_ready()
        if not ready:
            self.set_status("配置不完整", COLOR_BAD, why)
            return
        stored = load_stored_key()
        if stored:
            self.key_text.delete("1.0", "end")
            self.key_text.insert("1.0", stored)
            self.set_status("已载入上次使用的卡密", COLOR_MUTED, "点击『校验卡密』继续。")
        else:
            self.set_status("请粘贴卡密后点击『校验卡密』", COLOR_MUTED,
                            "提示：Ctrl+Enter 也能校验。")

    def on_paste(self) -> None:
        try:
            data = self.root.clipboard_get()
        except Exception:
            self.set_status("剪贴板为空", COLOR_WARN, "请先复制卡密（形如 WSK1-…）。")
            return
        self.key_text.delete("1.0", "end")
        self.key_text.insert("1.0", "".join(data.split()))
        self.set_status("已从剪贴板粘贴，点击『校验卡密』", COLOR_MUTED, "")

    def on_clear(self) -> None:
        self.key_text.delete("1.0", "end")
        self.license = None
        self.result = None
        self.btn_run.configure(state="disabled")
        self.progress.configure(value=0)
        self.set_info([])
        self.set_status("已清空", COLOR_MUTED, "")

    def on_copy_machine(self) -> None:
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self.machine_label.cget("text"))
            self.set_status("机器码已复制到剪贴板", COLOR_MUTED, "")
        except Exception as error:  # noqa: BLE001
            self.set_status("复制失败", COLOR_BAD, str(error))

    def on_verify(self) -> None:
        ready, why = config_ready()
        if not ready:
            self.set_status("配置不完整", COLOR_BAD, why)
            return

        key = "".join(self.current_key().split())
        if not key:
            self.set_status("请输入卡密", COLOR_WARN, "卡密形如 WSK1-XXXXX-XXXXX-…")
            self.btn_run.configure(state="disabled")
            return

        try:
            result = verify(key, embedded_public_key(), revoke=REVOKED or None)
        except LicenseError as error:
            self.set_status("卡密格式错误", COLOR_BAD, str(error))
            self.btn_run.configure(state="disabled")
            return
        except Exception as error:  # noqa: BLE001
            self.set_status("校验异常", COLOR_BAD, f"{type(error).__name__}: {error}")
            self.btn_run.configure(state="disabled")
            return

        self.result = result
        self.license = result.license

        if result.ok and self.license is not None:
            self.verified_key = key
            if self.remember.get():
                save_stored_key(key)
            self.set_status("校验通过，可以开始使用", COLOR_OK, "")
            self._show_license(self.license)
            self.btn_run.configure(state="normal")
        else:
            self.verified_key = ""
            self.set_status("校验未通过", COLOR_BAD, result.reason)
            self.progress.configure(value=0)
            self.btn_run.configure(state="disabled")
            if self.license is not None:
                self._show_license(self.license, note=result.reason)
            else:
                self.set_info(["卡密无法解析或签名无效。",
                               "请确认整串拷贝完整（含前缀 WSK1-），中途不要有换行或空格丢失。"])

    def _show_license(self, license_, note: str = "") -> None:
        import time

        rows = [
            f"授权对象：{license_.name or '(未填写)'}",
            f"有效期至：{license_.exp_text()}",
            f"机器绑定：{license_.machine or '(未绑定，任意电脑可用)'}",
            f"卡密编号：{license_.key_id}",
            f"签发时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(license_.issued_at))}",
        ]
        if note:
            rows.append(f"问题：{note}")

        # 进度条 = 剩余有效期比例（永久则拉满）
        if license_.is_perpetual:
            self.progress.configure(value=100)
            rows.append("剩余：永久有效")
        else:
            raw = f"{license_.expires:08d}"
            import datetime

            try:
                end = datetime.date(int(raw[:4]), int(raw[4:6]), int(raw[6:]))
                today = datetime.date.today()
                days_left = (end - today).days
                total = max((end - datetime.date.fromtimestamp(license_.issued_at)).days, 1)
                ratio = max(0.0, min(1.0, days_left / total)) * 100
                self.progress.configure(value=ratio)
                if days_left < 0:
                    rows.append(f"剩余：已过期 {abs(days_left)} 天")
                else:
                    rows.append(f"剩余：{days_left} 天")
            except Exception:
                self.progress.configure(value=0)
        self.set_info(rows)

    def on_run(self) -> None:
        target = resolve_target()
        if target is None:
            messagebox.showerror("找不到程序",
                                 f"配置的目标程序不存在：\n{TARGET_PROGRAM}\n\n"
                                 f"请在 授权验证_界面.py 里修改 TARGET_PROGRAM。")
            return
        self.root.withdraw()
        try:
            code = subprocess.call([sys.executable, target], cwd=os.path.dirname(target))
        except Exception as error:  # noqa: BLE001
            self.root.deiconify()
            messagebox.showerror("启动失败", str(error))
            return
        self.root.deiconify()
        self.root.lift()
        self.set_status(f"程序已结束（退出码 {code}）", COLOR_MUTED, "")


# --------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="授权验证_界面.py",
        description="图形界面版授权验证（tkinter，无第三方依赖）。",
    )
    parser.add_argument("--key", help="直接带入卡密并自动校验")
    parser.add_argument("--check", action="store_true",
                        help="不开窗口，只做自检（配置、界面构建、卡密校验）")
    parser.add_argument("--machine", help="覆盖机器码（测试绑定用）")
    parser.add_argument("--target", help="覆盖被保护程序路径（现场调试用）")
    args = parser.parse_args(argv)

    if args.check:
        ready, why = config_ready()
        print(f"配置就绪: {ready}" + (f"  ({why})" if why else ""))
        print(f"公钥前缀: {embedded_public_key()[:32]}...")
        target = resolve_target(args.target or "")
        print(f"目标程序: {target or '找不到 → ' + TARGET_PROGRAM}")

        # 卡密校验：打包成 exe 后，这是唯一能确认"内嵌公钥是否正确"的手段
        exit_code = 0 if ready else 1
        if args.key:
            result = verify(
                "".join(args.key.split()),
                embedded_public_key(),
                revoke=REVOKED or None,
                machine=args.machine,
            )
            print(f"卡密校验: {'通过' if result.ok else '拒绝'} —— {result.reason}")
            if result.license:
                print(f"  授权对象: {result.license.name or '(未填写)'}")
                print(f"  有效期至: {result.license.exp_text()}")
                print(f"  机器绑定: {result.license.machine or '(未绑定)'}")
            # 期望结果：通过=0，拒绝=1（测试脚本据此断言）
            exit_code = 0 if result.ok else 1

        try:
            root = tk.Tk()
            root.withdraw()
            LicenseWindow(root, preset_key=args.key or "")
            root.update_idletasks()
            root.destroy()
            print("界面构建: OK")
        except Exception:
            import traceback

            traceback.print_exc()
            return 1
        return exit_code

    root = tk.Tk()
    LicenseWindow(root, preset_key=(args.key or "").strip())
    root.mainloop()
    return 0


def _crash_log_path() -> str:
    """崩溃日志位置。

    优先用户目录（打包后一定可写，也不受工作目录影响），
    退而求其次才用程序目录。**不能用临时解包目录**——onefile 退出就被删。
    """
    candidates = [
        os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "wsk-license"),
        program_dir(),
    ]
    for directory in candidates:
        try:
            os.makedirs(directory, exist_ok=True)
            probe = os.path.join(directory, ".w_test")
            with open(probe, "w", encoding="utf-8") as handle:
                handle.write("x")
                handle.flush()
                os.fsync(handle.fileno())
            os.remove(probe)
            return os.path.join(directory, "启动日志.txt")
        except Exception:
            continue
    return ""


def _log(message: str) -> None:
    """把启动过程写进日志。窗口程序没有控制台，日志是唯一线索。

    刻意用最简单的 open/write/close（不用 with、不依赖项目中任何其他函数），
    并且**把自身的失败也记下来**：打包后如果日志写不进去，至少能在
    程序目录留下 .log_error 说明原因，而不是静默什么都没写。
    """
    path = _crash_log_path()
    if not path:
        return
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n"
    try:
        handle = open(path, "a", encoding="utf-8")
        handle.write(line)
        handle.close()
    except Exception as error:  # noqa: BLE001
        # 兜底：把失败原因写到程序目录，避免"日志是空的、什么线索都没有"
        try:
            fallback = os.path.join(program_dir(), "日志写入失败.txt")
            with open(fallback, "a", encoding="utf-8") as handle:
                handle.write(f"{line}  >>> 写入失败: {type(error).__name__}: {error}\n")
        except Exception:
            pass


def run_gui(argv: list[str] | None = None) -> int:
    """真正的入口：任何异常都写日志 + 弹窗，绝不让窗口无声消失。"""
    _log(f"启动: argv={sys.argv[1:]}  打包={FROZEN}  解释器={sys.executable}")
    try:
        code = main(argv)
        _log(f"正常退出: {code}")
        return code
    except SystemExit as exc:
        _log(f"SystemExit: {exc.code}")
        raise
    except BaseException:
        import traceback

        detail = traceback.format_exc()
        _log("崩溃:\n" + detail)
        # 窗口程序没有控制台，必须弹窗告诉用户去哪看日志
        try:
            import tkinter.messagebox

            tkinter.messagebox.showerror(
                "程序启动失败",
                f"发生未预期的错误，程序无法继续。\n\n{detail.strip().splitlines()[-1]}\n\n"
                f"详细信息已写入:\n{_crash_log_path()}",
            )
        except Exception:
            pass
        return 3


if __name__ == "__main__":
    raise SystemExit(run_gui())
