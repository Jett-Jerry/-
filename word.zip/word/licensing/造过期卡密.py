"""测试辅助：用私钥签发一张**已经过期**的卡密。

为什么不直接用 ``--days -1``：argparse 会把 ``-1`` 当成选项名，
``--days`` 实际拿到的是默认值（实测 exit=2）。所以过期卡密只能这样造。

    python 造过期卡密.py [天数偏移，默认 -30]
"""

from __future__ import annotations

import os
import sys
import time

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from 签发工具 import load_keypair  # noqa: E402
from 卡密核心 import encode_key, ed25519_sign  # noqa: E402

# 复用卡密核心的打包逻辑，但把到期日改成过去
from 卡密核心 import License, _pack  # noqa: E402


def main() -> int:
    # 双击时没有参数，用默认值；参数非法时给出人话提示而不是 ValueError 堆栈
    raw = sys.argv[1] if len(sys.argv) > 1 else ""
    if raw in ("-h", "--help"):
        print("用法: python 造过期卡密.py [天数偏移]")
        print("  天数偏移为负数表示到期日在过去，默认 -30（即 30 天前到期）")
        print("  例: python 造过期卡密.py -90   # 造一张 90 天前就过期的卡密")
        return 0
    try:
        offset_days = int(raw) if raw else -30
    except ValueError:
        print(f"参数必须是整数天数，收到: {raw!r}")
        print("用法: python 造过期卡密.py [天数偏移]")
        return 2

    try:
        pair = load_keypair()
    except SystemExit as error:
        print(error)
        return 1

    if offset_days >= 0:
        print(f"提示: 偏移 {offset_days} 天不是过去的时间，这张卡密不会过期。"
              f"想造过期卡密请传负数，例如 -30。")

    expires = int(time.strftime("%Y%m%d", time.localtime(time.time() + offset_days * 86400)))
    license_ = License(
        key_id="expiredtest00001",
        expires=expires,
        machine="",
        name="过期测试",
        issued_at=int(time.time()),
    )
    payload = _pack(license_)
    signature = ed25519_sign(pair.private_seed, payload)
    key = encode_key(payload, signature)

    print("=" * 74)
    print(f"已过期卡密（到期日 {expires}，偏移 {offset_days} 天）—— 仅用于测试")
    print("=" * 74)
    print(key)
    print("=" * 74)
    print("用它验证授权验证.py 会正确拒绝：")
    print(f'  python 授权验证.py --key "{key[:40]}..."')

    # 双击场景（无参数 + 真控制台）停下来让人看清结果
    if not raw:
        parent = os.path.dirname(HERE)
        if parent not in sys.path:
            sys.path.insert(0, parent)
        try:
            from 环境自测 import has_real_console, wait_for_keypress

            if has_real_console():
                print("\n" + "-" * 70)
                wait_for_keypress()
        except Exception:  # noqa: BLE001
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
