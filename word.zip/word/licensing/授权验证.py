"""被保护程序入口：校验卡密通过后才运行目标程序。

    python 授权验证.py                     交互式输入卡密
    python 授权验证.py --key WSK1-XXXX-... 直接带卡密运行
    python 授权验证.py --machine-id        打印本机机器码（发给发行方做绑定）
    python 授权验证.py --info              只看卡密状态，不运行目标程序
    python 授权验证.py --forget            清除本机已保存的卡密

被保护程序需要内嵌的东西（见下方 PUBLIC_KEY_TEXT / REVOKED）：
  1. 公钥   —— ``python 签发工具.py public`` 的输出
  2. 吊销名单（可选）—— ``dist/revoked.json`` 的内容
私钥绝不出现在这里；因此即使本程序被反编译，也无法伪造卡密。
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from 卡密核心 import LicenseError, describe, machine_id, verify  # noqa: E402

# ==========================================================================
# 嵌入区：只有这两项需要按发行方信息替换
# ==========================================================================
# 用 `python 签发工具.py public` 取公钥，粘贴到下面（去掉换行）
PUBLIC_KEY_TEXT = """
DIJL6L7DT4QK6IKTPTEZJDAV6FWEMSUFRLOG4LXZB6DT674WFOUA
"""

# 用 `python 签发工具.py export` 生成 revoked.json，把 key_id 列表填进来
REVOKED: set[str] = set()

# 要保护的程序（相对本文件），以及最大尝试次数
TARGET_PROGRAM = "../环境自测.py"
MAX_ATTEMPTS = 5
# ==========================================================================


STORE_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "wsk-license")
STORE_PATH = os.path.join(STORE_DIR, "token.json")


# --------------------------------------------------------------------------
def load_stored_key() -> str:
    try:
        with open(STORE_PATH, encoding="utf-8") as handle:
            return str(json.load(handle).get("key", ""))
    except Exception:
        return ""


def save_stored_key(key: str) -> str:
    try:
        os.makedirs(STORE_DIR, exist_ok=True)
        with open(STORE_PATH, "w", encoding="utf-8") as handle:
            json.dump({"key": key, "saved_at": int(time.time())}, handle)
        if os.name != "nt":
            os.chmod(STORE_PATH, 0o600)
        return STORE_PATH
    except Exception as error:
        return f"(保存失败: {error})"


def forget_stored_key() -> bool:
    try:
        os.remove(STORE_PATH)
        return True
    except FileNotFoundError:
        return False
    except Exception:
        return False


def embedded_public_key() -> str:
    return "".join(PUBLIC_KEY_TEXT.split())


def banner(title: str) -> None:
    print("=" * 78)
    print(f"  {title}")
    print("=" * 78)


# --------------------------------------------------------------------------
def check_key(key: str, *, quiet: bool = False):
    public = embedded_public_key()
    if not public or "REPLACE_ME" in public:
        print("【配置错误】本程序尚未嵌入有效公钥。")
        print("请发行方运行  python 签发工具.py public  并把输出粘贴到 授权验证.py 的 PUBLIC_KEY_TEXT。")
        return None
    result = verify(key, public, revoke=REVOKED or None)
    if not quiet:
        if result.ok:
            print("卡密校验通过。")
        else:
            print(f"卡密无效：{result.reason}")
    return result


def prompt_for_key() -> str:
    machine = machine_id()
    banner("需要卡密才能使用本程序")
    print(f"  本机机器码 : {machine}")
    print(f"  完整卡密   : 形如 WSK1-XXXXX-XXXXX-... ，从发行方获取")
    print(f"  输入 q 退出")
    print("-" * 78)
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            key = input(f"[{attempt}/{MAX_ATTEMPTS}] 请输入卡密: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return ""
        if key.lower() in ("q", "quit", "exit"):
            return ""
        if not key:
            print("  （输入为空，请重新输入）")
            continue
        result = check_key(key)
        if result and result.ok:
            return key
        print(f"  请核对后重试（剩余 {MAX_ATTEMPTS - attempt} 次）")
    print("\n尝试次数过多，已退出。")
    return ""


def resolve_target() -> str | None:
    """定位被保护程序：先看本目录，再看上一级目录。

    这样 TARGET_PROGRAM 既可以写同级文件（如 "你的程序.py"），
    也可以写 "../环境自测.py" 这种跨目录路径。
    """
    if os.path.isabs(TARGET_PROGRAM):
        return TARGET_PROGRAM if os.path.exists(TARGET_PROGRAM) else None
    candidates = [
        os.path.join(HERE, TARGET_PROGRAM),
        os.path.abspath(os.path.join(HERE, "..", TARGET_PROGRAM)),
    ]
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return None


def run_target(extra: list[str]) -> int:
    target = resolve_target()
    if target is None:
        print(f"找不到目标程序: {TARGET_PROGRAM}")
        print(f"  已尝试: {os.path.join(HERE, TARGET_PROGRAM)}")
        print(f"          {os.path.abspath(os.path.join(HERE, '..', TARGET_PROGRAM))}")
        return 2
    print("-" * 78)
    print(f"授权通过，正在运行 {os.path.basename(target)} ...")
    print("-" * 78 + "\n")
    # 必须 flush：子进程直接写同一个控制台，若这里还留在缓冲区里，
    # 子进程的输出会跑到前面去，看起来像"结果丢了"。
    sys.stdout.flush()
    sys.stderr.flush()
    try:
        # cwd 设为目标程序所在目录，这样它的相对路径依赖仍然成立
        return subprocess.call([sys.executable, target, *extra], cwd=os.path.dirname(target))
    except Exception as error:  # noqa: BLE001
        print(f"启动目标程序失败: {error}")
        return 2


# --------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="授权验证.py",
        description="卡密校验入口：验证通过后才运行被保护程序。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python 授权验证.py                     交互式输入卡密\n"
            "  python 授权验证.py --key WSK1-...      直接带卡密运行\n"
            "  python 授权验证.py --machine-id        打印本机机器码\n"
            "  python 授权验证.py --info              只看状态\n"
            "  python 授权验证.py --forget            清除本机已保存的卡密\n"
            "  python 授权验证.py --target X.py       临时改跑 X.py（不改配置文件）\n"
        ),
    )
    parser.add_argument("--key", help="直接提供卡密（不写入本机）")
    parser.add_argument("--machine-id", action="store_true", help="打印本机机器码后退出")
    parser.add_argument("--info", action="store_true", help="只显示卡密状态，不运行目标程序")
    parser.add_argument("--forget", action="store_true", help="清除本机已保存的卡密")
    parser.add_argument("--target", help="临时覆盖被保护程序（测试/调试用）")
    # parse_known_args：不属于 gate 的参数（例如 --live）原样透传给被保护程序。
    # 若用 parse_args，argparse 遇到未知参数会直接报错并以 exit=2 退出。
    args, passthrough = parser.parse_known_args(argv)

    if args.target:
        global TARGET_PROGRAM
        TARGET_PROGRAM = args.target

    if args.machine_id:
        print(machine_id())
        return 0

    if args.forget:
        print("已清除本机保存的卡密。" if forget_stored_key() else "本机没有保存过卡密。")
        return 0

    # 1) 优先用命令行传入的卡密
    key = (args.key or "").strip()

    # 2) 其次用本机缓存的卡密
    if not key:
        key = load_stored_key()

    # 3) 都没有就交互式索要
    if not key:
        key = prompt_for_key()
        if not key:
            return 1
        result = check_key(key, quiet=True)
        if not result or not result.ok:
            print(f"卡密无效：{result.reason if result else '未配置公钥'}")
            return 1
        where = save_stored_key(key)
        print(f"已保存到本机，下次无需再输入: {where}")

    result = check_key(key)
    if not result or not result.ok:
        return 1

    banner("卡密信息")
    if result.license:
        print(describe(result.license))
    print("=" * 78)
    if result.license:
        try:
            print(
                f"  剩余有效期 : "
                f"{'永久' if result.license.is_perpetual else result.license.exp_text()}"
            )
        except Exception:
            pass
    sys.stdout.flush()

    if args.info:
        return 0

    return run_target(passthrough)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except LicenseError as error:
        print(f"错误: {error}", file=sys.stderr)
        raise SystemExit(1) from None
