"""实测 签发工具.exe：私钥是否被正确分离、能否批量签发、产物能否被 授权验证.exe 认可。"""

from __future__ import annotations

import csv
import os
import shutil
import subprocess
import sys
import tempfile

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
failures = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<44} {detail}")
    if not ok:
        failures += 1


print("=" * 78)
print("签发工具.exe 实测")
print("=" * 78)

issue_exe_src = os.path.join(HERE, "dist_exe", "签发工具.exe")
gui_exe_src = os.path.join(HERE, "dist_exe", "授权验证.exe")
check("签发工具.exe 存在", os.path.exists(issue_exe_src),
      f"{os.path.getsize(issue_exe_src) / 1024 / 1024:.1f} MB" if os.path.exists(issue_exe_src) else "缺失")
if not os.path.exists(issue_exe_src):
    raise SystemExit(1)

# ---- 搭"发行方的工作目录"：exe + 私钥 + 公钥 + 台账 ----
work = tempfile.mkdtemp(prefix="wsk-issuer-")
issue_exe = os.path.join(work, "签发工具.exe")
shutil.copy2(issue_exe_src, issue_exe)

clean_env = {k: v for k, v in os.environ.items()
             if k.upper() not in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP")}
clean_env["LOCALAPPDATA"] = tempfile.mkdtemp(prefix="wsk-issuer-store-")


def run(*args: str, cwd: str = work, timeout: int = 300) -> tuple[int, str]:
    done = subprocess.run([issue_exe, *args], cwd=cwd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=timeout, env=clean_env)
    return done.returncode, (done.stdout or "") + (done.stderr or "")


# ---- 1. 没有私钥时应该报错而不是崩溃 ----
print("\n=== 1. 没有私钥时的行为 ===")
code, out = run("list")
print(f"  exit={code}")
for line in out.splitlines()[:4]:
    print(f"  | {line.strip()}")
check("缺私钥时不崩溃、给出提示", code == 0 or "私钥" in out, f"exit={code}")

# ---- 2. 放入私钥/公钥后能工作 ----
print("\n=== 2. 放入密钥文件后 ===")
for name in ("私钥_保管好.txt", "公钥.txt", "台账.json"):
    src = os.path.join(HERE, name)
    if os.path.exists(src):
        shutil.copy2(src, os.path.join(work, name))
print("  已复制: " + ", ".join(sorted(os.listdir(work))))

code, out = run("list")
check("list 可用", code == 0, f"exit={code}")

# ---- 3. 单个签发 ----
print("\n=== 3. 单个签发 ===")
code, out = run("issue", "--days", "30", "--name", "exe签发客户")
check("单个签发成功", code == 0 and "WSK1-" in out, f"exit={code}")
single_key = ""
for line in out.splitlines():
    if line.strip().startswith("WSK1-"):
        single_key = line.strip()
        break
check("拿到卡密", bool(single_key))

# ---- 4. 批量签发 + CSV 导出 ----
print("\n=== 4. 批量签发 10 张 ===")
code, out = run("batch", "--count", "10", "--days", "365",
                "--name", "批量{n:03d}", "--out", "批量卡密.csv")
check("批量签发成功", code == 0, f"exit={code}")
check("报告了数量", "签发数量 : 10" in out, "")
check("导出 CSV", "已导出" in out)

csv_path = os.path.join(work, "批量卡密.csv")
check("CSV 文件已生成", os.path.exists(csv_path))
if os.path.exists(csv_path):
    with open(csv_path, encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle))
    check("CSV 有 11 行（表头+10）", len(rows) == 11, f"{len(rows)} 行")
    check("CSV 带 BOM（Excel 不乱码）", open(csv_path, "rb").read(3) == b"\xef\xbb\xbf")
    batch_key = rows[1][6]
else:
    batch_key = ""

# ---- 5. exe 签发的卡密能被 授权验证.exe 认可（关键跨程序验证）----
print("\n=== 5. 跨程序验证：签发工具.exe 出的卡密 → 授权验证.exe 校验 ===")
if os.path.exists(gui_exe_src) and single_key:
    verify_dir = tempfile.mkdtemp(prefix="wsk-user-")
    verify_exe = os.path.join(verify_dir, "授权验证.exe")
    shutil.copy2(gui_exe_src, verify_exe)

    for label, key in (("单个签发", single_key), ("批量签发", batch_key)):
        if not key:
            continue
        done = subprocess.run(
            [verify_exe, "--check", "--key", key],
            cwd=verify_dir, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=300, env=clean_env,
        )
        text = (done.stdout or "") + (done.stderr or "")
        check(f"{label}的卡密被授权验证.exe 接受", done.returncode == 0, f"exit={done.returncode}")
        for line in text.splitlines():
            if "卡密校验" in line or "授权对象" in line:
                print(f"      {line.strip()}")
else:
    check("跨程序验证", False, "缺少产物")

# ---- 6. 私钥没有被包进 exe（安全要点）----
print("\n=== 6. 安全检查：exe 里有没有私钥 ===")
from 签发工具 import load_keypair  # noqa: E402

pair = load_keypair()
exe_bytes = open(issue_exe_src, "rb").read()
secret_ascii = pair.private_text.encode("ascii")
# 私钥以 Base32 文本形式存在时才是泄露；打包不会包含工作目录的 txt
check("exe 内未包含私钥文本", secret_ascii not in exe_bytes, f"私钥长度 {len(secret_ascii)}")

print("\n=== 分发清单 ===")
for name in sorted(os.listdir(work)):
    print(f"  {name:<24} {os.path.getsize(os.path.join(work, name)):>10} bytes")
print(f"\n  发行方工作目录: {work}")
print("=" * 78)
print(f"  {'全部通过 ✔' if not failures else str(failures) + ' 项失败'}")
print("=" * 78)
raise SystemExit(1 if failures else 0)
