"""一键跑全部测试。

    python 运行测试.py          全部（核心 32 项 + 端到端 26 项 + 交互 12 项）
    python 运行测试.py 核心      只跑某一套
"""

from __future__ import annotations

import os
import subprocess
import sys

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))

SUITES = [
    ("核心", "测试_核心.py"),
    ("端到端", "测试_端到端.py"),
    ("交互", "测试_交互.py"),
    ("界面", "测试_界面.py"),
    ("批量", "测试_批量.py"),
    # 下面两套需要先打包（python 打包.py），没打包时会被自动跳过
    ("exe界面", "测试_exe.py"),
    ("exe签发", "测试_exe签发.py"),
]


def main() -> int:
    wanted = sys.argv[1] if len(sys.argv) > 1 else ""
    selected = [item for item in SUITES if not wanted or wanted in item[0]]

    if not selected:
        print(f"没有匹配的测试套件: {wanted}")
        print("可选: " + " / ".join(name for name, _ in SUITES))
        return 2

    env = dict(os.environ)
    env["SELFTEST_NO_PAUSE"] = "1"   # 任何情况下都不进入等待
    env["PYTHONIOENCODING"] = "utf-8"

    print("=" * 74)
    print("卡密系统测试")
    print("=" * 74)

    failed: list[str] = []
    skipped: list[str] = []
    for name, script in selected:
        path = os.path.join(HERE, script)
        if not os.path.exists(path):
            print(f"  {name:<8} 缺失: {script}")
            failed.append(name)
            continue
        # exe 相关的套件需要先打包；没打包就跳过而不是报失败
        if name.startswith("exe") and not os.path.exists(os.path.join(HERE, "dist_exe", "授权验证.exe")):
            print(f"  {name:<8} 跳过（尚未打包，先运行 python 打包.py）")
            skipped.append(name)
            continue
        done = subprocess.run(
            [sys.executable, path],
            cwd=HERE,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            timeout=1200,
        )
        output = (done.stdout or "") + (done.stderr or "")
        passed = output.count("PASS")
        fails = output.count("FAIL")
        status = "通过" if done.returncode == 0 else "失败"
        print(f"  {name:<8} {status}   ({passed} 项通过 / {fails} 项失败)")
        if done.returncode != 0:
            failed.append(name)
            for line in output.splitlines():
                if "FAIL" in line:
                    print(f"           {line.strip()}")

    print("-" * 74)
    ran = len(selected) - len(skipped)
    if failed:
        print(f"  结果: {ran - len(failed)}/{ran} 套通过，失败: {', '.join(failed)}")
        if skipped:
            print(f"  跳过: {', '.join(skipped)}")
        return 1
    print(f"  结果: 全部 {ran} 套通过 ✔" + (f"（跳过 {len(skipped)} 套：{', '.join(skipped)}）" if skipped else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
