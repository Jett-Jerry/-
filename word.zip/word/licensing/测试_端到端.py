"""授权验证.py + 签发工具.py 端到端测试：模拟真实使用流程。

每一轮都用子进程真实调用命令行，而不是直接调函数 —— 这样测的是用户实际路径。
"""

from __future__ import annotations

import os
import re
import subprocess
import sys

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
failures = 0

# 隔离"记住的卡密"：把 LOCALAPPDATA 指到临时目录，否则本机一旦存过卡密，
# "无卡密时退出"这类用例会因为自动读取缓存而误判（踩过一次）。
import tempfile  # noqa: E402

ISOLATED = tempfile.mkdtemp(prefix="wsk-e2e-")
TEST_ENV = dict(os.environ, LOCALAPPDATA=ISOLATED, SELFTEST_NO_PAUSE="1", PYTHONIOENCODING="utf-8")


def run(args: list[str], stdin: str = "") -> tuple[int, str]:
    # 自动补 --target 测试用替身.py：让测试与 授权验证.py 里配置的目标程序解耦。
    # （否则改一次 TARGET_PROGRAM 就把整套测试带崩 —— 已经踩过这个坑。）
    if args and args[0] == "授权验证.py" and "--target" not in args:
        args = [args[0], "--target", "测试用替身.py", *args[1:]]
    done = subprocess.run(
        [PY, *args],
        cwd=HERE,
        input=stdin,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
        env=TEST_ENV,
    )
    return done.returncode, (done.stdout or "") + (done.stderr or "")


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<40} {detail}")
    if not ok:
        failures += 1


VERBOSE = os.environ.get("E2E_VERBOSE") == "1"


def dump(label: str, code: int, output: str) -> None:
    if not VERBOSE:
        return
    print(f"\n----- {label} (exit={code}) -----")
    for line in output.splitlines()[:14]:
        print(f"    | {line}")
    print("-----")


def extract_key(output: str) -> str:
    match = re.search(r"(WSK1-[A-Z0-9-]+)", output)
    return match.group(1) if match else ""


print("=" * 78)
print("端到端测试：签发 → 校验 → 运行被保护程序")
print("=" * 78)

# 每次都从干净台账开始，否则上一轮的同名记录会干扰这里的正则匹配（踩过）。
LEDGER = os.path.join(HERE, "台账.json")
if os.path.exists(LEDGER):
    os.remove(LEDGER)
    print("  (已重置台账，保证测试可重复)")

# ---- 1. 签发永久卡密 -------------------------------------------------
code, out = run(["签发工具.py", "issue", "--perpetual", "--name", "测试客户甲"])
dump("签发永久卡密", code, out)
check("签发永久卡密", code == 0, f"exit={code}")
perpetual_key = extract_key(out)
check("拿到卡密字符串", bool(perpetual_key), f"{perpetual_key[:34]}...")

# ---- 2. 用该卡密运行被保护程序 --------------------------------------
code, out = run(["授权验证.py", "--key", perpetual_key, "--target", "测试用替身.py"])
dump("有效卡密放行", code, out)
check("有效卡密放行", code == 0 and "被保护程序已启动" in out, f"exit={code}")
check("显示了卡密信息", "测试客户甲" in out and "永久" in out)

# ---- 3. 伪造卡密（改字符）被拒 --------------------------------------
tampered = perpetual_key[:-2] + ("AA" if not perpetual_key.endswith("AA") else "BB")
code, out = run(["授权验证.py", "--key", tampered])
dump("篡改卡密", code, out)
check("篡改卡密被拒", code != 0 and "签名无效" in out, f"exit={code}")

# ---- 4. 乱码卡密被拒 ------------------------------------------------
code, out = run(["授权验证.py", "--key", "WSK1-AAAAA-AAAAA-AAAAA"])
check("乱码卡密被拒", code != 0, f"exit={code}")

# ---- 5. 空卡密被拒（非交互）-----------------------------------------
code, out = run(["授权验证.py", "--key", ""], stdin="\nq\n")
check("无卡密时退出", code != 0, f"exit={code}")

# ---- 6. 过期卡密被拒 ------------------------------------------------
# 不能写 --days -1：argparse 会把 -1 当成选项名（实测 exit=2）。
# 用辅助脚本直接签发一张到期日在过去的卡密。
code, out = run(["造过期卡密.py", "-30"])
dump("签发过期卡密", code, out)
check("能造出已过期卡密", code == 0 and "WSK1-" in out, f"exit={code}")
expired_key = extract_key(out)
code, out = run(["授权验证.py", "--key", expired_key])
dump("过期卡密校验", code, out)
check("过期卡密被拒", code != 0 and "过期" in out, f"exit={code}")

# ---- 6b. 负天数签发必须成功（回归）-----------------------------------
# 曾经的 bug：签发后的自检调用了 verify()，而它默认检查有效期，于是
# "故意签一张过期卡密"这种正常用法被误报为
# "内部错误: 刚签发的卡密未通过自检 —— 卡密已过期"。
code, out = run(["签发工具.py", "issue", "--days", "-30", "--name", "故意过期"])
dump("负天数签发", code, out)
check("负天数签发成功（不再误报自检失败）", code == 0 and "WSK1-" in out, f"exit={code}")
check("给出了已过期提示", "已过期" in out)
negative_key = extract_key(out)
if negative_key:
    code, out = run(["授权验证.py", "--key", negative_key])
    check("这张过期卡密确实被拒", code != 0 and "过期" in out, f"exit={code}")

# ---- 7. 机器绑定 ----------------------------------------------------
code, mid_out = run(["授权验证.py", "--machine-id"])
this_machine = mid_out.strip()
check("能取到本机机器码", len(this_machine) >= 8, this_machine)

code, out = run(["签发工具.py", "issue", "--days", "30", "--bind", "--name", "绑定本机"])
bound_key = extract_key(out)
check("签发绑定卡密", code == 0 and this_machine[:8] in out, f"机器码 {this_machine[:8]}")
code, out = run(["授权验证.py", "--key", bound_key])
check("绑定本机的卡密通过", code == 0, f"exit={code}")

# ---- 8. --info 只看状态不运行 --------------------------------------
code, out = run(["授权验证.py", "--key", perpetual_key, "--info"])
dump("--info", code, out)
check("--info 显示卡密信息", code == 0 and "卡密信息" in out, f"exit={code}")
check("--info 不运行目标程序", "被保护程序已启动" not in out)

# ---- 9. 参数透传 ----------------------------------------------------
code, out = run(["授权验证.py", "--key", perpetual_key, "--live", "--quiet"])
dump("参数透传", code, out)
check("参数透传给目标程序", code == 0 and "'--live'" in out and "--quiet" in out, f"exit={code}")

# ---- 10. 台账与吊销 ------------------------------------------------
code, out = run(["签发工具.py", "list"])
check("台账列表可用", code == 0 and "测试客户甲" in out, f"{len(out.splitlines())} 行")

code, out = run(["签发工具.py", "revoke", "不存在的编号"])
check("吊销不存在的编号报错", code != 0, f"exit={code}")

# 取一张卡的编号并吊销，验证台账状态变化
code, out = run(["签发工具.py", "issue", "--days", "10", "--name", "待吊销"])
dump("签发待吊销卡密", code, out)
revoke_key = extract_key(out)
# 直接从「卡密编号」行取，比对台账做正则匹配可靠得多
match = re.search(r"卡密编号\s*:\s*(\w+)", out)
key_id = match.group(1) if match else ""
check("能从签发输出取到编号", bool(key_id), key_id)

if key_id:
    code, out = run(["签发工具.py", "revoke", key_id])
    check("吊销成功", code == 0 and "已吊销" in out)
    code, out = run(["签发工具.py", "list"])
    check("台账反映吊销状态", "已吊销" in out)

    # 关键：把编号写进 gate 的吊销名单后必须拒绝
    gate_text = open(os.path.join(HERE, "授权验证.py"), encoding="utf-8").read()
    patched = gate_text.replace("REVOKED: set[str] = set()", f'REVOKED: set[str] = {{"{key_id}"}}')
    check("能注入吊销名单", patched != gate_text)
    if patched != gate_text:
        backup = gate_text
        with open(os.path.join(HERE, "授权验证.py"), "w", encoding="utf-8") as handle:
            handle.write(patched)
        try:
            code, out = run(["授权验证.py", "--key", revoke_key])
            check("已吊销卡密被拒", code != 0 and "吊销" in out, f"exit={code}")
        finally:
            with open(os.path.join(HERE, "授权验证.py"), "w", encoding="utf-8") as handle:
                handle.write(backup)

# ---- 11. export -----------------------------------------------------
code, out = run(["签发工具.py", "export"])
check("export 生成分发文件", code == 0 and "公钥.txt" in out, "")
dist_pub = os.path.join(HERE, "分发", "公钥.txt")
dist_rev = os.path.join(HERE, "分发", "revoked.json")
check("dist/公钥.txt 存在", os.path.exists(dist_pub))
check("dist/revoked.json 存在", os.path.exists(dist_rev))
if os.path.exists(dist_rev):
    import json

    data = json.load(open(dist_rev, encoding="utf-8"))
    check("吊销名单内容正确", any(item.get("key_id") == key_id for item in data.get("keys", [])),
          f"{len(data.get('keys', []))} 条")

print()
print("=" * 78)
if failures:
    print(f"  {failures} 项失败")
    raise SystemExit(1)
print("  端到端全部通过 ✔")
print("=" * 78)
raise SystemExit(0)

