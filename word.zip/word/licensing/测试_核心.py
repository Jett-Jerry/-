"""用 RFC 8032 官方测试向量验证 Ed25519 实现，然后做端到端卡密测试。"""

from __future__ import annotations

import os
import sys

# 中文 Windows 控制台默认 GBK，先切成 UTF-8，否则输出符号/中文会崩。
for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from 卡密核心 import (  # noqa: E402
    KeyPair,
    ed25519_public_from_private,
    ed25519_sign,
    ed25519_verify,
    encode_key,
    decode_key,
    generate_keypair,
    issue,
    machine_id,
    verify,
)

failures = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<46} {detail}")
    if not ok:
        failures += 1


def h(text: str) -> bytes:
    return bytes.fromhex(text)


print("=" * 78)
print("第一部分：RFC 8032 Ed25519 官方向量对照")
print("=" * 78)

# RFC 8032 §7.1 的 TEST 1 / TEST 2 / TEST 3（含 SHA(abc) 变体）
vectors = [
    (
        "TEST 1 (空消息)",
        "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
        "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
        "",
        "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
        "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b",
    ),
    (
        "TEST 2 (1 字节)",
        "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
        "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c",
        "72",
        "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da"
        "085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00",
    ),
    (
        "TEST 3 (2 字节)",
        "c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
        "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025",
        "af82",
        "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac"
        "18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a",
    ),
]

for name, seed_hex, pub_hex, msg_hex, sig_hex in vectors:
    seed = h(seed_hex)
    expected_pub = h(pub_hex)
    message = h(msg_hex)
    expected_sig = h(sig_hex)

    derived = ed25519_public_from_private(seed)
    check(f"{name} 公钥推导", derived == expected_pub, f"{derived.hex()[:24]}...")

    produced = ed25519_sign(seed, message)
    check(f"{name} 签名生成", produced == expected_sig, f"{produced.hex()[:24]}...")

    check(f"{name} 签名校验", ed25519_verify(expected_pub, message, expected_sig))

# 负向：篡改消息 / 篡改签名 / 换公钥，都必须拒绝
seed = h(vectors[0][1])
pub = h(vectors[0][2])
sig = h(vectors[0][4])
check("拒绝被篡改的消息", not ed25519_verify(pub, b"tampered", sig))
bad_sig = bytearray(sig)
bad_sig[0] ^= 0x01
check("拒绝被篡改的签名", not ed25519_verify(pub, b"", bytes(bad_sig)))
other_pub = ed25519_public_from_private(bytes(range(32)))
check("拒绝错误公钥", not ed25519_verify(other_pub, b"", sig))
check("拒绝畸形签名长度", not ed25519_verify(pub, b"", sig[:32]))
check("拒绝畸形公钥长度", not ed25519_verify(pub[:16], b"", sig))

print()
print("=" * 78)
print("第二部分：卡密端到端")
print("=" * 78)

keypair = generate_keypair()
check("密钥对生成", len(keypair.private_seed) == 32 and len(keypair.public_key) == 32)

# 永久卡密
key, lic = issue(keypair, perpetual=True, name="张三")
check("永久卡密签发", key.startswith("WSK1-"), f"{key[:40]}...")
result = verify(key, keypair.public_key)
check("永久卡密校验通过", bool(result), result.reason)
check("卡密名称保留", result.license.name == "张三", result.license.name)
check("永久卡密显示", result.license.exp_text() == "永久")

# 有效期卡密
key30, lic30 = issue(keypair, days=30, name="李四")
check("30 天卡密校验通过", bool(verify(key30, keypair.public_key)), "")
future = int(lic30.expires) + 1
check("过期后被拒", not verify(key30, keypair.public_key, today=future), "")
check("到期前一天仍有效", bool(verify(key30, keypair.public_key, today=int(lic30.expires))))

# 机器绑定
mid = machine_id()
keym, _ = issue(keypair, days=10, machine=mid, name="王五")
check("绑定本机通过", bool(verify(keym, keypair.public_key)))
check("绑定他机被拒", not verify(keym, keypair.public_key, machine="ZZZZZZZZ"))

# 吊销
keyr, licr = issue(keypair, days=10, name="赵六")
check("吊销前通过", bool(verify(keyr, keypair.public_key)))
check("吊销后被拒", not verify(keyr, keypair.public_key, revoke={licr.key_id}))

# 伪造：换一对密钥签发的卡密必须被拒
attacker = generate_keypair()
forged, _ = issue(attacker, perpetual=True, name="伪造者")
check("他人私钥签发的卡密被拒", not verify(forged, keypair.public_key))

# 篡改：改一个字符（保持合法 Base32）
tampered = list(key)
index = len(tampered) - 3
tampered[index] = "A" if tampered[index] != "A" else "B"
check("篡改卡密字符被拒", not verify("".join(tampered), keypair.public_key))

# 格式错误
check("空卡密被拒", not verify("", keypair.public_key))
check("乱码卡密被拒", not verify("HELLO-WORLD", keypair.public_key))
check("错误公钥校验被拒", not verify(key, attacker.public_key))

# 往返一致性
payload, signature = decode_key(key)
check("编解码往返", len(payload) == 84 and len(signature) == 64, f"payload={len(payload)} sig={len(signature)}")

# ---- 名称字段往返（回归）--------------------------------------------
# 曾经的 bug：固定长度字段用 text.encode("utf-8")[:size] 按字节硬截，
# "界面测试客户" 存进去再读出来变成 "界面测试客?" —— 最后一个汉字被从中间切断。
for label, value in [
    ("5 个汉字", "界面测试客户"),
    ("2 个汉字", "张三"),
    ("中英混合", "ABC公司"),
    ("emoji", "客户🐍"),
    ("超长（会被安全截断）", "非常非常长的客户名称超出字段容量"),
    ("空", ""),
]:
    _, lic = issue(keypair, days=30, name=value)
    got = lic.name
    if len(value.encode("utf-8")) <= 24:
        ok = got == value
        detail = f"{value!r} -> {got!r}"
    else:
        # 超长时应被截断，但必须是完整字符、不能出现替换符
        ok = value.startswith(got) and "\ufffd" not in got
        detail = f"{value!r} -> {got!r}（安全截断）"
    check(f"名称往返：{label}", ok, detail)

# 带名称的卡密必须能通过校验，且校验后名称完整
named_key, named_lic = issue(keypair, days=30, name="界面测试客户")
named_result = verify(named_key, keypair.public_key)
check("带中文名的卡密可校验", bool(named_result), named_result.reason)
if named_result.license:
    check("校验后名称完整", named_result.license.name == "界面测试客户",
          repr(named_result.license.name))

# 旧版（v1 布局）卡密仍要能解析，不能因为改了布局就静默乱码
import struct as _struct  # noqa: E402

from 卡密核心 import _pack as _pack_new, encode_key as _encode  # noqa: E402

old_blob = (
    _struct.pack("<B", 1)
    + _struct.pack("<I", 20270101)
    + b"oldkeyid00000001"
    + b"\x00" * 8                      # 不绑定机器，专注验证布局兼容
    + "老客户".encode("utf-8").ljust(16, b"\x00")[:16]
    + _struct.pack("<I", 1700000000)
    + b"\x00" * (84 - 49)
)
from 卡密核心 import ed25519_sign as _sign  # noqa: E402

old_key = _encode(old_blob, _sign(keypair.private_seed, old_blob))
old_result = verify(old_key, keypair.public_key)
check("旧版(v1)卡密仍可校验", bool(old_result), old_result.reason)
if old_result.license:
    check("旧版卡密字段解析正确",
          old_result.license.name == "老客户" and old_result.license.expires == 20270101,
          f"name={old_result.license.name!r} exp={old_result.license.expires}")

# 未知版本号要明确报错，不能瞎解析
bad_version = bytearray(old_blob)
bad_version[0] = 9
bad_key = _encode(bytes(bad_version), _sign(keypair.private_seed, bytes(bad_version)))
bad_result = verify(bad_key, keypair.public_key)
check("未知版本被明确拒绝",
      not bad_result and "版本" in bad_result.reason, bad_result.reason)

# 私钥文本往返
restored = KeyPair.from_private_text(keypair.private_text)
check("私钥文本往返", restored.public_key == keypair.public_key)

print()
print("=" * 78)
if failures:
    print(f"  {failures} 项失败")
    raise SystemExit(1)
print("  全部通过 ✔  Ed25519 实现与 RFC 8032 完全一致，卡密流程正常")
print("=" * 78)
raise SystemExit(0)
