"""功能测试：不开窗口，用假 Tk 驱动界面版的真实校验逻辑。

覆盖：有效卡密放行、篡改卡密被拒、过期卡密被拒、绑定他机被拒、
吊销卡密被拒、空输入、剪贴板粘贴、机器码显示、授权信息渲染。
"""

from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
import tkinter as tk

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
failures = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<40} {detail}")
    if not ok:
        failures += 1


def load_gui():
    path = os.path.join(HERE, "授权验证_界面.py")
    spec = importlib.util.spec_from_file_location("gui", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def issue(args: list[str]) -> str:
    done = subprocess.run(
        [sys.executable, os.path.join(HERE, "签发工具.py"), "issue", *args],
        cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    for line in done.stdout.splitlines():
        if line.strip().startswith("WSK1-"):
            return line.strip()
    return ""


print("=" * 76)
print("授权验证_界面.py 功能测试")
print("=" * 76)

gui = load_gui()
check("模块可导入", gui is not None)
check("公钥已嵌入", "REPLACE_ME" not in gui.embedded_public_key(),
      gui.embedded_public_key()[:24] + "...")
ready, why = gui.config_ready()
check("配置就绪", ready, why)

root = tk.Tk()
root.withdraw()
window = gui.LicenseWindow(root)
root.update_idletasks()
check("界面构建成功", True)
check("显示了机器码", len(window.machine_label.cget("text")) >= 8,
      window.machine_label.cget("text"))

# ---- 1. 有效卡密 ----
good = issue(["--days", "30", "--name", "界面测试客户"])
check("签发出测试卡密", bool(good), good[:28] + "..." if good else "")
window.key_text.delete("1.0", "end")
window.key_text.insert("1.0", good)
window.on_verify()
check("有效卡密放行", window.result is not None and window.result.ok,
      window.result.reason if window.result else "")
check("状态文字变绿", "通过" in window.status.cget("text"), window.status.cget("text"))
check("『运行程序』按钮已启用", str(window.btn_run.cget("state")) == "normal")
info = window.info_text.get("1.0", "end")
check("授权信息显示客户名", "界面测试客户" in info)
check("授权信息显示有效期", "有效期至" in info)
check("进度条已更新", window.progress.cget("value") > 0,
      f"{window.progress.cget('value'):.1f}")

# ---- 2. 篡改卡密 ----
tampered = good[:-2] + ("AA" if not good.endswith("AA") else "BB")
window.key_text.delete("1.0", "end")
window.key_text.insert("1.0", tampered)
window.on_verify()
check("篡改卡密被拒", window.result is not None and not window.result.ok)
check("按钮回到禁用", str(window.btn_run.cget("state")) == "disabled")

# ---- 3. 空输入 ----
window.key_text.delete("1.0", "end")
window.on_verify()
check("空输入给出提示", "请输入" in window.status.cget("text"),
      window.status.cget("text"))

# ---- 4. 乱码 ----
window.key_text.delete("1.0", "end")
window.key_text.insert("1.0", "HELLO-WORLD-123")
window.on_verify()
check("乱码被拒", window.result is not None and not window.result.ok)

# ---- 5. 过期卡密 ----
expired = issue(["--days", "-30", "--name", "过期客户"])
window.key_text.delete("1.0", "end")
window.key_text.insert("1.0", expired)
window.on_verify()
check("过期卡密被拒", window.result is not None and not window.result.ok)
check("提示含『过期』", "过期" in window.detail.cget("text"), window.detail.cget("text"))

# ---- 6. 卡密带换行/空格也要能识别 ----
wrapped = good[:50] + "\n   " + good[50:120] + "\n" + good[120:]
window.key_text.delete("1.0", "end")
window.key_text.insert("1.0", wrapped)
window.on_verify()
check("换行/空格不影响识别", window.result is not None and window.result.ok)

# ---- 7. 清空 ----
window.on_clear()
check("清空后按钮禁用", str(window.btn_run.cget("state")) == "disabled")
check("清空后输入为空", window.current_key() == "")

# ---- 8. 剪贴板粘贴 ----
try:
    root.clipboard_clear()
    root.clipboard_append(good)
    window.on_paste()
    check("剪贴板粘贴成功", window.current_key() == good)
except Exception as error:
    check("剪贴板粘贴成功", False, str(error))

# ---- 9. 机器码复制 ----
try:
    root.clipboard_clear()
    window.on_copy_machine()
    check("机器码可复制", root.clipboard_get() == window.machine_label.cget("text"))
except Exception as error:
    check("机器码可复制", False, str(error))

root.destroy()

print()
print("=" * 76)
print(f"  {'全部通过 ✔' if not failures else str(failures) + ' 项失败'}")
print("=" * 76)
raise SystemExit(1 if failures else 0)
