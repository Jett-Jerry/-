"""把 授权验证.py 的配置同步到 授权验证_界面.py。

同步三项：公钥、吊销名单、目标程序。这样命令行入口和界面入口永远共用同一份
授权信息，不会出现"命令行能过、界面过不了"的怪事。

    python _embed_gui.py            同步
    python _embed_gui.py --check    只检查是否已同步
"""

from __future__ import annotations

import re
import sys

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

import os

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = os.path.join(HERE, "授权验证.py")
TARGET = os.path.join(HERE, "授权验证_界面.py")

PUBLIC_RE = re.compile(r'(PUBLIC_KEY_TEXT = """)(.*?)(""")', re.S)
REVOKED_RE = re.compile(r"^REVOKED[^\n=]*=\s*([^\n]+)$", re.M)
TARGET_RE = re.compile(r'^TARGET_PROGRAM\s*=\s*(.+)$', re.M)


def extract(path: str) -> dict[str, str]:
    with open(path, encoding="utf-8") as handle:
        text = handle.read()

    public = PUBLIC_RE.search(text)
    revoked = REVOKED_RE.search(text)
    target = TARGET_RE.search(text)

    if not (public and revoked and target):
        missing = [
            name for name, match in
            (("PUBLIC_KEY_TEXT", public), ("REVOKED", revoked), ("TARGET_PROGRAM", target))
            if not match
        ]
        raise SystemExit(f"在 {os.path.basename(path)} 里找不到: {', '.join(missing)}")

    return {
        "public": public.group(2).strip(),
        "revoked": revoked.group(1).strip(),
        "target": target.group(1).strip(),
    }


def to_ascii_literal(value: str) -> str:
    """把含中文的 Python 字面量转成纯 ASCII 的 \\uXXXX 形式。

    这样生成的 .py 文件即使被以非 UTF-8 方式读取也不会损坏（例如被 .bat 处理）。
    """
    out = []
    for ch in value:
        out.append(ch if ord(ch) < 128 else f"\\u{ord(ch):04x}")
    return "".join(out)


def main() -> int:
    config = extract(SOURCE)
    print("从 授权验证.py 读到：")
    print(f"  公钥      : {config['public'][:40]}...")
    print(f"  吊销名单  : {config['revoked']}")
    print(f"  目标程序  : {config['target']}")

    with open(TARGET, encoding="utf-8") as handle:
        gui = handle.read()

    original = gui

    # 1) 公钥
    if not PUBLIC_RE.search(gui):
        raise SystemExit("在 授权验证_界面.py 里找不到 PUBLIC_KEY_TEXT 块")
    gui = PUBLIC_RE.sub(
        lambda m: f'{m.group(1)}\n{config["public"]}\n{m.group(3)}',
        gui,
        count=1,
    )

    # 2) 吊销名单
    # 注意：必须用 lambda，不能让 re.sub 把替换串里的反斜杠当转义
    # （目标程序路径含 \uXXXX，直接传字符串会报 "bad escape \u"）。
    gui = REVOKED_RE.sub(lambda _m: f"REVOKED: set[str] = {config['revoked']}", gui, count=1)

    # 3) 目标程序（中文路径写成 \u 转义，保持文件 ASCII 安全）
    ascii_target = config["target"]
    if any(ord(ch) > 127 for ch in ascii_target):
        match = re.match(r'^(["\'])(.*)(["\'])$', ascii_target)
        if match:
            ascii_target = f"{match.group(1)}{to_ascii_literal(match.group(2))}{match.group(3)}"
    gui = TARGET_RE.sub(lambda _m: f"TARGET_PROGRAM = {ascii_target}", gui, count=1)

    changed = gui != original
    if changed:
        with open(TARGET, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(gui)
        print("\n已同步到 授权验证_界面.py")
    else:
        print("\n配置本来就是最新的，未改动")

    # 校验
    import ast

    try:
        ast.parse(gui)
        print("语法检查: OK")
    except SyntaxError as error:
        print(f"语法检查: 失败 {error}")
        return 1

    if "REPLACE_ME" in PUBLIC_RE.search(gui).group(2):
        print("警告: 界面文件的公钥仍是 REPLACE_ME 占位符")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
