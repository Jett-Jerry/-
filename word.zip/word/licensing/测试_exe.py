"""实测打包出来的 exe：模拟真实部署（exe + 被保护程序放同一目录）。

重点验证 exe **自己**的判断能力（不是拿源码里的公钥代替）：
  * 有效卡密 → exe 返回 0
  * 篡改卡密 → exe 返回 1
  * 过期卡密 → exe 返回 1
  * 绑定他机 → exe 返回 1
并确认不需要 Python 环境变量、能找到同目录的被保护程序。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile

for _s in ("stdout", "stderr"):
    h = getattr(sys, _s, None)
    if h is not None and hasattr(h, "reconfigure"):
        try:
            h.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
failures = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global failures
    print(f"  {'PASS' if ok else 'FAIL'}  {name:<44} {detail}")
    if not ok:
        failures += 1


print("=" * 78)
print("打包产物实测（模拟用户部署）")
print("=" * 78)

exe_src = os.path.join(HERE, "dist_exe", "授权验证.exe")
check("exe 存在", os.path.exists(exe_src),
      f"{os.path.getsize(exe_src) / 1024 / 1024:.1f} MB" if os.path.exists(exe_src) else "缺失")
if not os.path.exists(exe_src):
    raise SystemExit(1)

# ---- 搭一个"用户的机器" ----
deploy = tempfile.mkdtemp(prefix="wsk-deploy-")
exe = os.path.join(deploy, "授权验证.exe")
shutil.copy2(exe_src, exe)
shutil.copy2(os.path.join(HERE, "测试用替身.py"), os.path.join(deploy, "被保护程序.py"))
print(f"\n部署目录: {deploy}")
for name in sorted(os.listdir(deploy)):
    print(f"  {name}")

# 干净环境（模拟没装 Python 的机器）
clean_env = {
    k: v for k, v in os.environ.items()
    if k.upper() not in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP")
}
clean_env["LOCALAPPDATA"] = tempfile.mkdtemp(prefix="wsk-exe-store-")


def run_exe(*extra: str, timeout: int = 300) -> tuple[int, str]:
    done = subprocess.run(
        [exe, *extra], cwd=deploy, capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=timeout, env=clean_env,
    )
    return done.returncode, (done.stdout or "") + (done.stderr or "")


# ---- 1. 基本自检 ----
print("\n=== 1. exe --check ===")
code, out = run_exe("--check")
print(f"  exit={code}")
for line in out.splitlines()[:6]:
    print(f"  | {line.strip()}")
check("exe 可运行、自检通过", code == 0, f"exit={code}")
check("内嵌公钥已生效", "配置就绪: True" in out)

# ---- 2. 卡密校验（由 exe 自己判断）----
from 卡密核心 import issue  # noqa: E402
from 签发工具 import load_keypair  # noqa: E402

pair = load_keypair()

good, good_lic = issue(pair, days=30, name="exe实测客户")
code, out = run_exe("--check", "--key", good)
check("exe 接受有效卡密", code == 0, f"exit={code}")
check("exe 读出授权对象", "exe实测客户" in out)

tampered = good[:-2] + ("AA" if not good.endswith("AA") else "BB")
code, out = run_exe("--check", "--key", tampered)
check("exe 拒绝篡改卡密", code != 0, f"exit={code}")
check("给出拒绝原因", "签名无效" in out or "拒绝" in out)

expired, _ = issue(pair, days=-30, name="过期")
code, out = run_exe("--check", "--key", expired)
check("exe 拒绝过期卡密", code != 0 and "过期" in out, f"exit={code}")

bound, _ = issue(pair, days=30, name="绑定他机", machine="ZZZZZZZZ")
code, out = run_exe("--check", "--key", bound)
check("exe 拒绝绑定他机的卡密", code != 0 and "绑定" in out, f"exit={code}")

perpetual, _ = issue(pair, perpetual=True, name="永久")
code, out = run_exe("--check", "--key", perpetual)
check("exe 接受永久卡密", code == 0 and "永久" in out, f"exit={code}")

# ---- 3. 目标程序定位 ----
print("\n=== 2. 目标程序定位 ===")
code, out = run_exe("--check")
target_line = [line for line in out.splitlines() if "目标程序" in line]
print(f"  {target_line[0].strip() if target_line else '(无)'}")
# exe 所在目录里没有 环境自测.py，所以理应报告找不到（这是正确行为）
check("找不到目标程序时如实报告", "找不到" in out or "环境自测.py" in out)

# 把替身改名成 exe 期望的名字，验证能找到
shutil.copy2(os.path.join(HERE, "测试用替身.py"), os.path.join(deploy, "环境自测.py"))
code, out = run_exe("--check")
found = [line for line in out.splitlines() if "目标程序" in line]
print(f"  放入 环境自测.py 后: {found[0].strip() if found else '(无)'}")
check("能找到同目录的被保护程序", "找不到" not in (found[0] if found else "找不到"))

print("\n=== 3. 分发清单 ===")
for name in sorted(os.listdir(deploy)):
    path = os.path.join(deploy, name)
    print(f"  {name:<22} {os.path.getsize(path):>10} bytes")

print(f"\n  部署目录（可手工检查）: {deploy}")
print("=" * 78)
print(f"  {'全部通过 ✔' if not failures else str(failures) + ' 项失败'}")
print("=" * 78)
raise SystemExit(1 if failures else 0)
