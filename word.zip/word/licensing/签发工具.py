"""卡密签发工具（keygen）—— 只在你自己手上运行，绝不外发。

    python 签发工具.py init                       生成密钥对
    python 签发工具.py issue --days 365 --name 张三
    python 签发工具.py issue --perpetual --name 大客户
    python 签发工具.py issue --days 30 --bind     生成时绑定本机
    python 签发工具.py list                       查看台账
    python 签发工具.py revoke KW-XXXXXXXX         吊销某张卡密
    python 签发工具.py public                     打印公钥（要嵌进被保护程序）
    python 签发工具.py selftest                   自检

安全约定
--------
* ``私钥_保管好.txt``（私钥）**只留在签发机器**，不要提交到 git、不要发给用户。
* ``公钥.txt``（公钥）才是要嵌进被保护程序的东西。
* 台账 ``台账.json`` 记录签发历史与吊销状态，用于管理，不参与签名校验。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any

for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from 卡密核心 import (  # noqa: E402
    KeyPair,
    LicenseError,
    describe,
    generate_keypair,
    issue,
    machine_id,
    verify,
)
from 批量签发 import DEFAULT_NAME_FORMAT, append_to_ledger, batch_issue, export  # noqa: E402
from 冻结环境 import program_dir  # noqa: E402

# 数据目录：源码运行时是脚本目录，打包成 exe 后是 exe 所在目录。
# 绝不能用 __file__（onefile 模式下它指向 %TEMP% 的解包目录，退出即被删除）。
DATA_DIR = program_dir()
# 密钥文件的搜索顺序：数据目录优先，其次脚本目录（兼容"exe 放在别处、
# 密钥留在 licensing 里"这种用法）
_SEARCH_DIRS = [DATA_DIR]
if os.path.abspath(HERE) != os.path.abspath(DATA_DIR):
    _SEARCH_DIRS.append(HERE)


def secret_path() -> str:
    """私钥路径。找不到时返回数据目录下的默认位置（供 init 创建）。

    刻意做成函数而不是模块级常量：exe 被拷到别处、或用户在程序启动后才生成
    密钥时，导入时算死的路径就失效了。
    """
    for directory in _SEARCH_DIRS:
        candidate = os.path.join(directory, "私钥_保管好.txt")
        if os.path.exists(candidate):
            return candidate
    return os.path.join(DATA_DIR, "私钥_保管好.txt")


def public_path() -> str:
    for directory in _SEARCH_DIRS:
        candidate = os.path.join(directory, "公钥.txt")
        if os.path.exists(candidate):
            return candidate
    return os.path.join(DATA_DIR, "公钥.txt")


def ledger_path() -> str:
    for directory in _SEARCH_DIRS:
        candidate = os.path.join(directory, "台账.json")
        if os.path.exists(candidate):
            return candidate
    return os.path.join(DATA_DIR, "台账.json")


# 兼容旧代码里的常量名（外部脚本可能引用）
SECRET_PATH = secret_path()
PUBLIC_PATH = public_path()
LEDGER_PATH = ledger_path()


# --------------------------------------------------------------------------
# 文件读写
# --------------------------------------------------------------------------
def _write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text if text.endswith("\n") else text + "\n")


def _restrict_permissions(path: str) -> str:
    """尽量把私钥文件权限收紧到"仅当前用户"。返回说明文本。"""
    if os.name != "nt":
        try:
            os.chmod(path, 0o600)
            return "已设为 0600"
        except Exception as error:
            return f"chmod 失败: {error}"
    try:
        import subprocess

        user = os.environ.get("USERNAME", "")
        if not user:
            return "未取到用户名，跳过"
        # /inheritance:r 断开继承，/grant:r 只给当前用户
        subprocess.run(
            ["icacls", path, "/inheritance:r", "/grant:r", f"{user}:F"],
            capture_output=True,
            check=False,
            timeout=20,
        )
        return f"已限制为仅 {user} 可访问"
    except Exception as error:
        return f"icacls 失败: {error}"


def load_keypair() -> KeyPair:
    if not os.path.exists(secret_path()):
        raise SystemExit(
            f"找不到私钥 {secret_path()}\n"
            f"请先运行:  python {os.path.basename(__file__)} init"
        )
    with open(secret_path(), encoding="utf-8") as handle:
        text = handle.read().strip()
    return KeyPair.from_private_text(text)


def load_ledger() -> dict[str, Any]:
    """读取台账。

    这里的错误处理很关键：**读失败绝不能静默当成空台账**。
    否则调用方紧接着 save_ledger() 就会把整个台账覆盖成只剩新记录 —— 真实的数据
    丢失路径（文件被临时占用、半写状态、杀毒软件扫描都会触发）。
    所以：读失败时重试几次；仍失败就抛出，让用户看到而不是默默丢数据。
    """
    path = ledger_path()
    if not os.path.exists(path):
        return {"keys": []}

    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
            if not isinstance(data, dict) or "keys" not in data:
                raise ValueError("台账格式异常（缺少 keys 字段）")
            return data
        except (OSError, json.JSONDecodeError, ValueError) as error:
            last_error = error
            time.sleep(0.15 * (attempt + 1))

    raise RuntimeError(
        f"读取台账失败: {path}\n  原因: {last_error}\n"
        f"  为避免覆盖丢失数据，已中止。请检查该文件是否被占用或内容损坏。"
    )


def save_ledger(ledger: dict[str, Any]) -> None:
    """原子写入台账：先写临时文件再替换，避免写到一半被中断导致文件损坏。"""
    path = ledger_path()
    temporary = f"{path}.tmp"
    with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(ledger, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)   # 原子替换（Windows 上同样成立）


# --------------------------------------------------------------------------
# 子命令
# --------------------------------------------------------------------------
def cmd_init(args: argparse.Namespace) -> int:
    if os.path.exists(secret_path()) and not args.force:
        pair = load_keypair()
        print(f"密钥已存在，未改动。\n私钥: {secret_path()}\n公钥: {public_path()}")
        print(f"\n公钥内容（嵌进被保护程序的就是它）:\n  {pair.public_text}")
        return 0

    pair = generate_keypair()
    _write_text(secret_path(), pair.private_text)
    _write_text(public_path(), pair.public_text)
    note = _restrict_permissions(secret_path())

    print("密钥对已生成")
    print(f"  私钥: {secret_path()}   ({note})")
    print(f"  公钥: {public_path()}")
    print("\n把下面这行公钥嵌进被保护程序（授权验证.py 已内置）:")
    print(f"  {pair.public_text}")
    print("\n警告: 私钥泄露 = 任何人都能签发卡密。切勿外发、切勿提交到 git。")
    if not os.path.exists(ledger_path()):
        save_ledger({"keys": []})
    return 0


def cmd_issue(args: argparse.Namespace) -> int:
    pair = load_keypair()

    # 注意：--days 的默认值必须留在 argparse 之外判断，否则 --perpetual
    # 会永远和"默认的 365 天"冲突。
    if args.perpetual and args.days is not None:
        print("--perpetual 与 --days 不能同时使用", file=sys.stderr)
        return 2
    days = 365 if args.days is None else args.days

    machine = ""
    if args.bind:
        machine = machine_id()
        print(f"绑定机器码: {machine}")

    key, license_ = issue(
        pair,
        days=days,
        name=args.name or "",
        machine=machine,
        perpetual=args.perpetual,
    )

    # 自检：这里要验的是「签名与载荷是否正确」，**不是有效期**。
    # 用 check_expiry=False 是刻意的 —— 用负数天数签发一张"故意过期"的卡密
    # （用于测试拒绝逻辑）是完全正常的用法，之前的自检会把它误报为
    # "内部错误: 刚签发的卡密未通过自检 —— 卡密已过期"。
    check = verify(key, pair.public_key, check_expiry=False)
    if not check:
        print(f"内部错误: 刚签发的卡密未通过自检 —— {check.reason}", file=sys.stderr)
        return 2
    if license_.expired():
        print(f"注意: 这是一张【已过期】的卡密（到期日 {license_.exp_text()}），"
              f"只能用来说明拒绝逻辑，不能正常授权。")

    ledger = load_ledger()
    ledger["keys"].append(
        {
            "key_id": license_.key_id,
            "name": license_.name,
            "expires": license_.expires,
            "machine": license_.machine,
            "issued_at": license_.issued_at,
            "issued_at_text": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(license_.issued_at)),
            "key": key,
            "revoked": False,
        }
    )
    save_ledger(ledger)

    print("\n" + "=" * 74)
    print("卡密已签发")
    print("=" * 74)
    print(describe(license_))
    print("-" * 74)
    print(key)
    print("=" * 74)
    if args.out:
        with open(args.out, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(f"# 授权对象: {license_.name or '(未填写)'}\n")
            handle.write(f"# 有效期至: {license_.exp_text()}\n")
            handle.write(f"# 机器绑定: {license_.machine or '(未绑定)'}\n")
            handle.write(key + "\n")
        print(f"已写入: {os.path.abspath(args.out)}")
    print(f"台账已更新: {ledger_path()}（共 {len(ledger['keys'])} 条）")
    return 0


def cmd_batch(args: argparse.Namespace) -> int:
    """批量签发：一次生成多张卡密并导出成表格。"""
    pair = load_keypair()

    if args.perpetual and args.days is not None:
        print("--perpetual 与 --days 不能同时使用", file=sys.stderr)
        return 2
    days = 365 if args.days is None else args.days

    machine = ""
    if args.bind:
        machine = machine_id()
        print(f"绑定机器码: {machine}")

    name_format = args.name or DEFAULT_NAME_FORMAT
    print(f"开始签发 {args.count} 张（名称模板 {name_format!r}）…")

    try:
        result = batch_issue(
            pair,
            count=args.count,
            days=days,
            perpetual=args.perpetual,
            name_format=name_format,
            machine=machine,
        )
    except ValueError as error:
        print(f"参数错误: {error}", file=sys.stderr)
        return 2

    # 自检：随机抽 3 张（不足则全查）验证签名，防止批量出错却没人发现
    import random

    sample = result.licenses if result.count <= 3 else random.sample(result.licenses, 3)
    for key, _ in sample:
        check = verify(key, pair.public_key, check_expiry=False)
        if not check:
            print(f"内部错误: 批量签发的卡密未通过自检 —— {check.reason}", file=sys.stderr)
            return 2

    # 导出
    out_path = args.out or "卡密.csv"
    try:
        written = export(result, out_path, args.format)
    except ValueError as error:
        print(f"导出失败: {error}", file=sys.stderr)
        return 2

    # 台账
    ledger = load_ledger()
    append_to_ledger(result, ledger)
    save_ledger(ledger)

    print("\n" + "=" * 74)
    print("批量签发完成")
    print("=" * 74)
    print(result.summary())
    print("-" * 74)
    for path in written:
        print(f"已导出: {os.path.abspath(path)}")
    print(f"台账已更新: {ledger_path()}（共 {len(ledger['keys'])} 条）")
    print("=" * 74)
    print("前 3 张示例：")
    for key, license_ in result.licenses[:3]:
        print(f"  {license_.name:<12} {key[:46]}…")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    ledger = load_ledger()
    entries = ledger.get("keys", [])
    if not entries:
        print("台账为空。")
        return 0

    today = int(time.strftime("%Y%m%d"))
    print(f"{'编号':<18}{'名称':<16}{'到期':<14}{'绑定':<10}{'状态':<10}")
    print("-" * 74)
    for item in entries:
        expires = int(item.get("expires", 0))
        if item.get("revoked"):
            status = "已吊销"
        elif expires and today > expires:
            status = "已过期"
        else:
            status = "有效"
        exp_text = "永久" if not expires else f"{expires:08d}"[:4] + "-" + f"{expires:08d}"[4:6] + "-" + f"{expires:08d}"[6:]
        print(
            f"{str(item.get('key_id', '')):<18}"
            f"{str(item.get('name') or '-'):<16}"
            f"{exp_text:<14}"
            f"{str(item.get('machine') or '-'):<10}"
            f"{status:<10}"
        )
    print("-" * 74)
    total = len(entries)
    revoked = sum(1 for item in entries if item.get("revoked"))
    print(f"共 {total} 条，已吊销 {revoked} 条")
    return 0


def cmd_revoke(args: argparse.Namespace) -> int:
    ledger = load_ledger()
    target = args.key_id.strip()
    hits = 0
    for item in ledger.get("keys", []):
        if str(item.get("key_id")) == target or str(item.get("key", "")).strip() == target:
            item["revoked"] = True
            item["revoked_at"] = int(time.time())
            hits += 1
    if not hits:
        print(f"台账中未找到: {target}", file=sys.stderr)
        return 1
    save_ledger(ledger)
    print(f"已吊销 {hits} 条记录: {target}")
    print("把导出后的吊销名单随程序一起分发，程序侧才会真正拒绝它。")
    return 0


def cmd_public(args: argparse.Namespace) -> int:
    pair = load_keypair()
    print(pair.public_text)
    return 0


def cmd_export(_args: argparse.Namespace) -> int:
    """导出被保护程序需要的两个文件：公钥 + 吊销名单。"""
    pair = load_keypair()
    ledger = load_ledger()
    revoked = [
        {"key_id": item.get("key_id"), "revoked": True, "name": item.get("name")}
        for item in ledger.get("keys", [])
        if item.get("revoked")
    ]
    out = os.path.join(HERE, "分发")
    os.makedirs(out, exist_ok=True)
    _write_text(os.path.join(out, "公钥.txt"), pair.public_text)
    with open(os.path.join(out, "revoked.json"), "w", encoding="utf-8", newline="\n") as handle:
        json.dump({"keys": revoked}, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(f"已导出到 {out}")
    print(f"  公钥.txt    —— 公钥")
    print(f"  revoked.json  —— 吊销名单（{len(revoked)} 条）")
    return 0


# --------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="签发工具.py",
        description="卡密签发工具（私钥持有方专用，切勿外发）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "典型流程:\n"
            "  python 签发工具.py init\n"
            "  python 签发工具.py issue --days 365 --name 张三 --out 张三.txt\n"
            "  python 签发工具.py list\n"
            "  python 签发工具.py revoke <编号>\n"
            "  python 签发工具.py export        # 生成给被保护程序的公钥与吊销名单\n"
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="生成密钥对（已存在则不覆盖）")
    p_init.add_argument("--force", action="store_true", help="覆盖已有密钥（旧的卡密会全部失效）")
    p_init.set_defaults(func=cmd_init)

    p_issue = sub.add_parser("issue", help="签发一张卡密")
    p_issue.add_argument("--days", type=int, default=None, help="有效天数（默认 365）")
    p_issue.add_argument("--perpetual", action="store_true", help="永久有效")
    p_issue.add_argument("--name", default="", help="授权对象名称/备注")
    p_issue.add_argument("--bind", action="store_true", help="绑定本机机器码")
    p_issue.add_argument("--out", help="把卡密写入指定文本文件")
    p_issue.set_defaults(func=cmd_issue)

    p_batch = sub.add_parser("batch", help="批量签发（一次生成多张并导出表格）")
    p_batch.add_argument("--count", "-n", type=int, required=True, help="签发数量")
    p_batch.add_argument("--days", type=int, default=None, help="有效天数（默认 365）")
    p_batch.add_argument("--perpetual", action="store_true", help="永久有效")
    p_batch.add_argument("--name", help="名称模板，支持 {n} 序号与 {total}，如 '张三{n:03d}'")
    p_batch.add_argument("--bind", action="store_true", help="全部绑定本机机器码")
    p_batch.add_argument("--out", help="导出路径（默认 卡密.csv）")
    p_batch.add_argument("--format", choices=["csv", "jsonl", "txt"], help="导出格式，默认按扩展名")
    p_batch.set_defaults(func=cmd_batch)

    p_list = sub.add_parser("list", help="查看台账")
    p_list.set_defaults(func=cmd_list)

    p_revoke = sub.add_parser("revoke", help="吊销卡密（按编号或卡密全文）")
    p_revoke.add_argument("key_id")
    p_revoke.set_defaults(func=cmd_revoke)

    p_public = sub.add_parser("public", help="打印公钥")
    p_public.set_defaults(func=cmd_public)

    p_export = sub.add_parser("export", help="导出公钥与吊销名单到 dist/")
    p_export.set_defaults(func=cmd_export)

    # 双击运行时没有任何参数：argparse 会报"缺少子命令"并 exit 2，窗口立刻消失，
    # 看起来就是"闪退"。这里改为显示帮助并停住，让人能看清怎么用。
    if not (argv if argv is not None else sys.argv[1:]):
        parser.print_help()
        print("\n提示：双击运行不会执行任何操作，请在命令行里带上子命令，例如：")
        print("  python 签发工具.py init")
        print("  python 签发工具.py issue --days 365 --name 张三")
        # 环境自测.py 在上一级目录，必须把父目录也加进 sys.path，
        # 否则 import 失败会被 except 吞掉，暂停就永远不会执行（踩过一次）。
        parent = os.path.dirname(HERE)
        if parent not in sys.path:
            sys.path.insert(0, parent)
        try:
            from 环境自测 import has_real_console, wait_for_keypress

            if has_real_console():
                print("\n" + "-" * 70)
                wait_for_keypress()
        except Exception as error:  # noqa: BLE001
            print(f"\n(提示: 无法启用按键等待: {error})", file=sys.stderr)
        return 0

    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except LicenseError as error:
        print(f"错误: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n已中断。")
        raise SystemExit(130) from None
