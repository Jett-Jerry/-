@echo off
rem ===========================================================================
rem  Launcher for the graphical license checker.
rem
rem  ASCII-only on purpose: cmd.exe parses a .bat with the OEM code page
rem  (GBK on Chinese Windows), so a Chinese filename here would be mangled
rem  and cmd would report 'The system cannot find the file specified'.
rem  All Chinese logic lives in _launcher.py, whose name is pure ASCII.
rem
rem  No setlocal/endlocal on purpose: endlocal resets ERRORLEVEL to 0.
rem ===========================================================================

chcp 65001 >nul 2>&1
cd /d "%~dp0"

set "PYTHON_CMD="
where python >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)

if not defined PYTHON_CMD (
    echo [ERROR] No python command found on PATH.
    set "EXITCODE=2"
    goto :finish
)

rem Use pythonw so the console window does not linger behind the GUI.
set "PYW=%~dp0..\_pythonw.cmd"
%PYTHON_CMD% "%~dp0_launcher.py" --gui %*
set "EXITCODE=%errorlevel%"

:finish
if not "%EXITCODE%"=="0" (
    echo.
    echo   Exit code: %EXITCODE%   (2 = python not found; 1 = GUI failed to start)
    pause
)
exit /b %EXITCODE%
