@echo off
rem ===========================================================================
rem  Environment self-test launcher.
rem
rem  This file is 100% ASCII on purpose.  cmd.exe parses a .bat with the OEM
rem  code page (GBK on Chinese Windows), so putting a Chinese filename here
rem  corrupts the bytes and cmd reports 'The system cannot find the file
rem  specified' (measured: exit 255).  Embedding Python code here also fails
rem  because cmd eats the quotes and % signs (measured: SyntaxError).
rem
rem  All real logic therefore lives in _launcher.py, whose name is pure ASCII.
rem
rem  No setlocal/endlocal on purpose: endlocal resets ERRORLEVEL to 0, which
rem  would silently swallow the exit code this script must propagate.
rem ===========================================================================

chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo ===========================================================================
echo   Environment self-test
echo   Directory: %~dp0
echo ===========================================================================
echo.

set "PYTHON_CMD="
where python >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)

if not defined PYTHON_CMD (
    echo [ERROR] No python command found on PATH.
    set "EXITCODE=2"
    goto :finish
)

%PYTHON_CMD% "%~dp0_launcher.py" %*
set "EXITCODE=%errorlevel%"

:finish
echo.
echo ---------------------------------------------------------------------------
echo   Exit code: %EXITCODE%    (0 = all passed, 1 = failures, 2 = script error)
echo ---------------------------------------------------------------------------
exit /b %EXITCODE%
