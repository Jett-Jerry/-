"""ASCII 名的启动辅助器，由 自测.bat 与 签发卡密.bat 调用。

为什么需要它
------------
cmd.exe 用 OEM 代码页（中文 Windows 是 GBK）解析 .bat：

* .bat 里出现中文文件名   -> 字节被破坏 -> "系统找不到指定的文件"
* .bat 里内嵌 Python 代码  -> 引号和 % 被吞 -> SyntaxError

所以批处理里只写一个 ASCII 文件名（本文件），中文逻辑全部放这里。

用途
----
    python _launcher.py                跑 环境自测.py（自测.bat 用，默认行为）
    python _launcher.py --live         同上，追加真实网络检查
    python _launcher.py --issue        交互式签发卡密（签发卡密.bat 用）
"""

from __future__ import annotations

import glob
import os
import re
import subprocess
import sys

# 中文 Windows 控制台默认 GBK：不切 UTF-8 的话打印中文/£/emoji 会直接崩
for _stream in ("stdout", "stderr"):
    _handle = getattr(sys, _stream, None)
    if _handle is not None and hasattr(_handle, "reconfigure"):
        try:
            _handle.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _fix_redirected_stdin() -> str:
    """stdin 被重定向/管道时，必须按 UTF-8 解码。

    实测：管道传中文进来时 ``sys.stdin.encoding`` 是 **gbk**、errors 是
    surrogateescape，UTF-8 字节被当 GBK 解码，末尾落单字节变成孤立代理字符
    （\\udc98），随后 ``name.encode("utf-8")`` 抛
    ``UnicodeEncodeError: surrogates not allowed``。

    但**真控制台不能改**：那里 input() 走 Unicode 控制台 API，跟 stdin.encoding
    无关；强行改成 UTF-8 反而可能让中文读成乱码。所以只在非终端时改。
    """
    handle = getattr(sys, "stdin", None)
    if handle is None or not hasattr(handle, "reconfigure"):
        return "无 stdin"
    try:
        is_console = handle.isatty()
    except Exception:
        is_console = False
    if is_console:
        return f"真控制台（保持 {handle.encoding}）"
    try:
        handle.reconfigure(encoding="utf-8", errors="replace")
        return "已重定向：改为 utf-8"
    except Exception as error:  # noqa: BLE001
        return f"重配置失败: {error}"


STDIN_MODE = _fix_redirected_stdin()

HERE = os.path.dirname(os.path.abspath(__file__))

SELF_TEST = "环境自测.py"
ISSUE_TOOL = "签发工具.py"
KEY_DIR = "卡密"

# 兜底识别：目标脚本里必然出现的常量（比文件名匹配更抗改名）
MARKERS = {
    SELF_TEST: "默认日志名",
    ISSUE_TOOL: "SECRET_PATH",
}
SELF_MARKER = "默认日志名"


# --------------------------------------------------------------------------
# 定位脚本
# --------------------------------------------------------------------------
def find_script(name: str) -> str | None:
    direct = os.path.join(HERE, name)
    if os.path.exists(direct):
        return direct
    marker = MARKERS.get(name)
    if not marker:
        return None
    for path in sorted(glob.glob(os.path.join(HERE, "*.py"))):
        if os.path.abspath(path) == os.path.abspath(__file__):
            continue
        if name == ISSUE_TOOL and os.path.dirname(path) == HERE:
            continue  # 签发工具在 licensing 子目录里，不在这里找
        try:
            with open(path, encoding="utf-8") as handle:
                if marker in handle.read():
                    return path
        except (OSError, UnicodeDecodeError):
            continue
    return None


def find_log_name(script: str) -> str | None:
    """取日志文件名，避免把中文写进 .bat。

    必须锚定到行首的常量赋值：只按长度匹配会误伤脚本里的测试数据字符串
    （实测抓到过 '价格 £12.50，库存 3 件'，恰好也是 16 字节）。
    """
    try:
        with open(script, encoding="utf-8") as handle:
            text = handle.read()
    except OSError:
        return None
    match = re.search(r"^\s*默认日志名\s*=\s*\"([^\"]+)\"", text, re.M)
    return match.group(1) if match else None


# --------------------------------------------------------------------------
# 用途一：跑环境自测
# --------------------------------------------------------------------------
def run_selftest(extra: list[str]) -> int:
    script = find_script(SELF_TEST)
    if script is None:
        print("[launcher] 找不到 环境自测.py", file=sys.stderr)
        return 3
    command = [sys.executable, script]
    log_name = find_log_name(script)
    if log_name:
        command += ["--log", os.path.join(HERE, log_name)]
    return subprocess.call(command + extra)


# --------------------------------------------------------------------------
# 用途二：交互式签发卡密
# --------------------------------------------------------------------------
def ask(prompt: str, default: str = "") -> str:
    """读一行输入；遇到 EOF（管道/CI）直接返回默认值，绝不卡死。"""
    suffix = f" [{default}]" if default else ""
    try:
        answer = input(f"{prompt}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return answer or default


def ask_days() -> int | None:
    """返回天数；0=永久；None=用户放弃。"""
    print("有效期：")
    print("  直接回车 = 365 天")
    print("  0        = 永久有效")
    print("  负数     = 立刻过期（只用来测试拒绝逻辑）")
    while True:
        raw = ask("天数", "365")
        if raw.lower() in ("q", "quit", "exit"):
            return None
        try:
            return int(raw)
        except ValueError:
            print(f"  『{raw}』不是整数，请重新输入，或按 q 退出")


def issue_one() -> int:
    tool = os.path.join(HERE, "licensing", ISSUE_TOOL)
    if not os.path.exists(tool):
        tool = find_script(ISSUE_TOOL) or ""
    if not tool or not os.path.exists(tool):
        print(f"[launcher] 找不到 {ISSUE_TOOL}", file=sys.stderr)
        return 3

    tool_dir = os.path.dirname(tool)
    secret = glob.glob(os.path.join(tool_dir, "私钥*.txt"))
    if not secret:
        print("还没有密钥对，请先运行一次：")
        print(f"  python licensing\\{ISSUE_TOOL} init")
        return 1

    print("=" * 70)
    print("  签发卡密")
    print("=" * 70)
    print("（任何一步输入 q 可退出）\n")

    days = ask_days()
    if days is None:
        print("已取消。")
        return 1

    name = ask("授权对象名称（谁用的，可留空）", "")
    if name.lower() in ("q", "quit", "exit"):
        print("已取消。")
        return 1

    bind = ask("绑定本机机器码？输入 y 绑定，回车不绑定", "")
    machine = bind.lower() in ("y", "yes", "是")

    command = [sys.executable, tool, "issue"]
    if days == 0:
        command.append("--perpetual")
    else:
        command += ["--days", str(days)]
    if name:
        command += ["--name", name]
    if machine:
        command.append("--bind")

    print()
    result = subprocess.run(command, cwd=tool_dir)
    if result.returncode != 0:
        print(f"\n签发失败（退出码 {result.returncode}）。")
        return result.returncode

    print("\n已记录到台账，可通过  python licensing\\签发工具.py list  查看。")
    print("把这串卡密发给用户，让他在 授权验证.py 里粘贴即可。")
    return 0


# --------------------------------------------------------------------------
# 用途三：打开图形界面版授权验证
# --------------------------------------------------------------------------
def launch_gui(extra: list[str]) -> int:
    """启动 licensing\\授权验证_界面.py。

    优先用 pythonw.exe（无控制台窗口），这样界面上不会挂着一个黑框；
    找不到就退回当前的 python.exe。
    """
    gui = os.path.join(HERE, "licensing", "授权验证_界面.py")
    if not os.path.exists(gui):
        print(f"[launcher] 找不到授权验证界面: {gui}", file=sys.stderr)
        return 1

    interpreter = sys.executable
    if os.name == "nt":
        candidate = os.path.join(os.path.dirname(interpreter), "pythonw.exe")
        if os.path.exists(candidate):
            interpreter = candidate

    # pythonw 没有控制台，异常不会显示；所以窗口模式失败时要能回退并提示
    try:
        process = subprocess.Popen([interpreter, gui, *extra], cwd=os.path.dirname(gui))
    except Exception as error:  # noqa: BLE001
        print(f"[launcher] 启动界面失败: {error}", file=sys.stderr)
        return 1

    if interpreter.endswith("pythonw.exe"):
        # 不等它，让批处理立刻退出，窗口不残留
        return 0

    return process.wait()


# --------------------------------------------------------------------------
def main() -> int:
    argv = sys.argv[1:]

    if argv and argv[0] in ("-h", "--help"):
        print("用法:")
        print("  python _launcher.py            跑环境自测（自测.bat 用）")
        print("  python _launcher.py --live     同上，追加真实网络检查")
        print("  python _launcher.py --issue    交互式签发卡密（签发卡密.bat 用）")
        print("  python _launcher.py --gui      打开图形界面版授权验证")
        return 0

    if argv and argv[0] == "--issue":
        return issue_one()

    if argv and argv[0] == "--gui":
        return launch_gui(argv[1:])

    # 默认行为 = 跑环境自测（保持与旧版 自测.bat 的兼容）
    extra = [item for item in argv if item != "--run"]
    return run_selftest(extra)


if __name__ == "__main__":
    try:
        code = main()
    except KeyboardInterrupt:
        print("\n已中断。")
        code = 130

    # 双击场景（真控制台）停下来让人看清结果
    try:
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        from 环境自测 import has_real_console, wait_for_keypress

        if has_real_console():
            print("\n" + "-" * 70)
            wait_for_keypress()
    except Exception:
        pass

    raise SystemExit(code)
