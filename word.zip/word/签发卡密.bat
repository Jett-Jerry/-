@echo off
rem ===========================================================================
rem  Interactive license issuing launcher.
rem
rem  This file is 100% ASCII on purpose.  cmd.exe parses a .bat with the OEM
rem  code page (GBK on Chinese Windows); a Chinese filename written here would
rem  be mangled into garbage bytes and cmd would report
rem  'The system cannot find the file specified'.  Embedding Python code here
rem  also fails because cmd eats the quotes and % signs.
rem
rem  All Chinese prompts therefore live in _launcher.py, whose name is ASCII.
rem
rem  No setlocal/endlocal on purpose: endlocal resets ERRORLEVEL to 0, which
rem  would swallow the exit code this script must propagate.
rem ===========================================================================

chcp 65001 >nul 2>&1
cd /d "%~dp0"

set "PYTHON_CMD="
where python >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)

if not defined PYTHON_CMD (
    echo [ERROR] No python command found on PATH.
    echo         Install Python, and tick "Add python.exe to PATH" during setup.
    set "EXITCODE=2"
    goto :finish
)

rem No extra arguments are forwarded: this entry point is menu-driven.
%PYTHON_CMD% "%~dp0_launcher.py" --issue
set "EXITCODE=%errorlevel%"

:finish
echo.
echo ---------------------------------------------------------------------------
echo   Exit code: %EXITCODE%    (0 = ok, 1 = cancelled / no keypair, 2 = no python)
echo ---------------------------------------------------------------------------
exit /b %EXITCODE%
