#!/usr/bin/env python3
"""工作区环境自测 —— 一条命令验证这台机器上的 Python 是否真的能用。

设计目标
--------
* **自包含**：只用标准库 + 已安装的第三方库，不依赖任何外部文件。
* **分层**：解释器 → 标准库 → 第三方库“能不能导入” → “能不能真干活” → （可选）真实网络。
* **诚实**：区分 PASS / FAIL / SKIP。缺网、缺包不会伪装成通过。
* **可脚本化**：退出码 0=全绿、1=有失败、2=自测脚本自身出错；`--json` 给机器读。

用法
----
    python 环境自测.py                # 离线自测（默认）
    python 环境自测.py --live         # 追加真实网络抓取/解析
    python 环境自测.py --json out.json
    python 环境自测.py --quiet        # 只输出失败项与总结
    python 环境自测.py -h
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sys
import tempfile
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable

VERSION = "1.0.0"


def force_utf8_output() -> tuple[str, str]:
    """让本脚本在任何控制台上都不会因编码问题崩溃。

    中文 Windows 的默认代码页是 GBK：打印 ``£``、emoji 或部分中文会直接抛
    ``UnicodeEncodeError``。这里做两件事：

    1. 把 stdout/stderr 重新配置为 UTF-8，并用 ``replace`` 兜底，保证永不崩溃；
    2. 在 Windows 上尝试把控制台代码页切成 65001，让中文正常显示而非乱码。

    返回 (原 stdout 编码, 是否成功切换控制台代码页)。
    """
    original = getattr(sys.stdout, "encoding", None) or "?"
    switched = False
    if os.name == "nt":
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32
            if kernel32.SetConsoleOutputCP(65001) and kernel32.SetConsoleCP(65001):
                switched = True
        except Exception:
            switched = False
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    return original, switched


# 默认日志文件名。放在这里是为了让 自测.bat 能用「字节长度」定位到它 ——
# cmd.exe 用 GBK 解析 .bat，所以批处理里不能出现中文，只能靠长度特征查找。
默认日志名 = "自测日志.txt"

# --------------------------------------------------------------------------
# 被测目标：本工作区原本用到的库；name = import 名, package = pip 安装名
# --------------------------------------------------------------------------
LIBS: list[tuple[str, str, str]] = [
    ("lxml", "lxml", "HTML/XML 解析、XPath —— 爬虫核心"),
    ("bs4", "beautifulsoup4", "备用解析后端"),
    ("requests", "requests", "HTTP 客户端"),
    ("charset_normalizer", "charset-normalizer", "编码猜测"),
    ("numpy", "numpy", "数值计算"),
    ("pandas", "pandas", "表格数据处理"),
    ("PIL", "Pillow", "图像读写"),
    ("docx", "python-docx", "Word 文档"),
    ("pptx", "python-pptx", "PowerPoint 文档"),
    ("openpyxl", "openpyxl", "Excel 读写（xlsx）"),
    ("xlsxwriter", "XlsxWriter", "Excel 写出"),
]

LIVE_URL = "https://books.toscrape.com/"
LIVE_EXPECT_ITEMS = 20

# 由 main() 在启动时填充：原始 stdout 编码 + 控制台是否已切到 UTF-8 代码页
ORIGINAL_STDIO_ENCODING = "?"
CONSOLE_UTF8 = False

# 用于验证多字节/非 ASCII 处理能力的样本
UNICODE_SAMPLE = "价格 £12.50 · 中文 · emoji 🐍 · Cyrillic Привет"

HTML_SAMPLE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Shop</title></head>
<body>
  <ul class="pager"><li class="current">Page 1</li><li>Page 2</li><li>Page 3</li></ul>
  <article class="product"><h3><a href="/p/1.html" title="One">One</a></h3><p class="price">£7.99</p></article>
  <article class="product"><h3><a href="/p/2.html" title="Two">Two</a></h3><p class="price">£14.99</p></article>
  <article class="product"><h3><a href="/p/3.html" title="Three">Three</a></h3><p class="price">£21.99</p></article>
  <table class="info"><tr><th>UPC</th><td>upc-001</td></tr></table>
</body></html>"""


# --------------------------------------------------------------------------
# 结果收集
# --------------------------------------------------------------------------
@dataclass
class Result:
    section: str
    name: str
    status: str  # PASS | FAIL | SKIP
    detail: str = ""
    error: str = ""
    seconds: float = 0.0


@dataclass
class Suite:
    results: list[Result] = field(default_factory=list)

    def record(self, section: str, name: str, status: str, detail: str = "", error: str = "", seconds: float = 0.0) -> None:
        self.results.append(Result(section, name, status, detail, error, seconds))

    def case(self, section: str, name: str, fn: Callable[[], Any], skip_if: str | None = None) -> None:
        """Run ``fn``; its return value (or raised exception) decides the status."""
        if skip_if is not None:
            self.record(section, name, "SKIP", skip_if)
            return
        started = time.perf_counter()
        try:
            detail = fn()
            self.record(section, name, "PASS", str(detail) if detail is not None else "", seconds=time.perf_counter() - started)
        except AssertionError as exc:
            self.record(section, name, "FAIL", error=f"断言失败: {exc}", seconds=time.perf_counter() - started)
        except Exception as exc:  # noqa: BLE001 - 自测必须捕获一切
            self.record(
                section,
                name,
                "FAIL",
                error=f"{type(exc).__name__}: {exc}",
                seconds=time.perf_counter() - started,
            )

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.status == "PASS")

    @property
    def failed(self) -> list[Result]:
        return [r for r in self.results if r.status == "FAIL"]

    @property
    def skipped(self) -> list[Result]:
        return [r for r in self.results if r.status == "SKIP"]


suite = Suite()


def module_available(name: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


# --------------------------------------------------------------------------
# 1. 解释器
# --------------------------------------------------------------------------
def section_interpreter() -> dict[str, Any]:
    section = "解释器"
    info: dict[str, Any] = {}

    def version() -> str:
        info.update(
            {
                "version": platform.python_version(),
                "implementation": platform.python_implementation(),
                "executable": sys.executable,
                "bits": 64 if sys.maxsize > 2**32 else 32,
                "prefix": sys.prefix,
                "site_packages": __import__("sysconfig").get_paths()["purelib"],
                "venv": sys.prefix != getattr(sys, "base_prefix", sys.prefix),
                "free_threaded": bool(sysconfig_free_threaded()),
            }
        )
        if sys.version_info < (3, 10):
            raise AssertionError(f"版本过低 {platform.python_version()}，需要 >= 3.10")
        return f"{platform.python_version()} {platform.python_implementation()} {'64' if info['bits'] == 64 else '32'}bit"

    def sysconfig_free_threaded() -> bool:
        import sysconfig

        return bool(sysconfig.get_config_var("Py_GIL_DISABLED"))

    suite.case(section, "版本与架构", version)

    def executable() -> str:
        if not os.path.isabs(sys.executable):
            raise AssertionError(f"解释器路径不是绝对路径: {sys.executable}")
        if not os.path.exists(sys.executable):
            raise AssertionError(f"解释器文件不存在: {sys.executable}")
        return sys.executable

    suite.case(section, "解释器路径可解析", executable)

    def writable() -> str:
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "写入测试.txt")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(UNICODE_SAMPLE)
            with open(path, encoding="utf-8") as handle:
                back = handle.read()
        if back != UNICODE_SAMPLE:
            raise AssertionError("读回内容与写入不一致")
        return f"UTF-8 读写往返正常（{len(back)} 字符，含中文/£/emoji）"

    suite.case(section, "临时目录可读写", writable)

    def stdio_encoding() -> str:
        encoding = getattr(sys.stdout, "encoding", None) or "?"
        # 真正打印一次多字节字符：控制台编码不对时这里就会炸
        sys.stdout.write(f"      · 多字节输出测试: {UNICODE_SAMPLE}\n")
        sys.stdout.flush()
        return f"stdout={encoding}, filesystem={sys.getfilesystemencoding()}, 控制台代码页={'65001' if CONSOLE_UTF8 else '未切换'}"

    suite.case(section, "控制台编码可输出非 ASCII", stdio_encoding)

    def help_is_utf8() -> str:
        """回归测试：``--help`` 由 argparse 直接输出，必须也是合法 UTF-8。

        这条曾经真的挂过——编码重配置写在 parse_args 之后，帮助文本按 GBK 吐出，
        中文变成非法字节。
        """
        import subprocess

        script = os.path.abspath(__file__)
        for flag, must_contain in (("--help", "工作区"), ("--version", "selftest")):
            done = subprocess.run(
                [sys.executable, script, flag],
                capture_output=True,
                timeout=60,
            )
            try:
                text = done.stdout.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise AssertionError(
                    f"`环境自测.py {flag}` 的输出不是合法 UTF-8（{exc}）——"
                    f"说明编码重配置没有在 argparse 之前生效"
                ) from exc
            if must_contain not in text:
                raise AssertionError(f"`环境自测.py {flag}` 输出缺少 {must_contain!r}")
        return "argparse 的 --help/--version 输出均为合法 UTF-8"

    suite.case(section, "帮助文本编码合法", help_is_utf8)

    return info


# --------------------------------------------------------------------------
# 2. 标准库
# --------------------------------------------------------------------------
def section_stdlib() -> None:
    section = "标准库"

    for name in (
        "json",
        "re",
        "csv",
        "sqlite3",
        "urllib.request",
        "http.server",
        "html",
        "xml.etree.ElementTree",
        "gzip",
        "zlib",
        "hashlib",
        "ssl",
        "concurrent.futures",
        "threading",
        "dataclasses",
        "argparse",
        "pathlib",
        "decimal",
        "datetime",
        "unicodedata",
    ):
        suite.case(section, f"import {name}", lambda n=name: __import__(n) and "")

    def sqlite_roundtrip() -> str:
        import sqlite3

        connection = sqlite3.connect(":memory:")
        try:
            connection.execute("create table t (a int, b text)")
            connection.executemany("insert into t values (?, ?)", [(1, "一"), (2, "二")])
            rows = connection.execute("select a, b from t order by a").fetchall()
        finally:
            connection.close()
        if rows != [(1, "一"), (2, "二")]:
            raise AssertionError(f"sqlite 读回异常: {rows}")
        return "内存库建表/写入/读回正常（含中文）"

    suite.case(section, "sqlite3 往返", sqlite_roundtrip)

    def regex_unicode() -> str:
        text = "价格 £12.50，库存 3 件"
        price = re.search(r"[\d.]+", text)
        count = re.search(r"(\d+)\s*件", text)
        if not price or price.group(0) != "12.50":
            raise AssertionError(f"价格正则异常: {price and price.group(0)}")
        if not count or count.group(1) != "3":
            raise AssertionError("中文量词正则异常")
        return f"提取 price={price.group(0)} count={count.group(1)}"

    suite.case(section, "正则 + Unicode", regex_unicode)

    def json_unicode() -> str:
        payload = {"名称": "书", "price": 7.99, "tags": ["a", "b"]}
        text = json.dumps(payload, ensure_ascii=False)
        back = json.loads(text)
        if back != payload:
            raise AssertionError("JSON 往返不一致")
        if "\\u" in text:
            raise AssertionError("ensure_ascii=False 仍被转义")
        return f"往返正常，字节数={len(text.encode('utf-8'))}"

    suite.case(section, "JSON 往返（非 ASCII 不转义）", json_unicode)


# --------------------------------------------------------------------------
# 3. 第三方库：能否导入 + 版本
# --------------------------------------------------------------------------
def section_imports() -> dict[str, str]:
    section = "第三方库导入"
    versions: dict[str, str] = {}

    for module, package, purpose in LIBS:
        def probe(m: str = module, p: str = package, why: str = purpose) -> str:
            imported = __import__(m)
            version = getattr(imported, "__version__", None)
            if version is None:
                import importlib.metadata as metadata

                try:
                    version = metadata.version(p)
                except Exception:
                    version = "未知"
            versions[m] = str(version)
            return f"{version}  —— {why}"

        suite.case(section, f"{package}", probe)

    return versions


# --------------------------------------------------------------------------
# 4. 第三方库：真能干活吗
# --------------------------------------------------------------------------
def section_functional() -> None:
    html_section = "功能 · HTML/爬虫"
    data_section = "功能 · 数据"
    doc_section = "功能 · 文档与图像"

    # ---- HTML / 爬虫 --------------------------------------------------
    def lxml_xpath() -> str:
        from lxml import html

        document = html.fromstring(HTML_SAMPLE)
        titles = document.xpath("//article[contains(@class,'product')]//h3/a/@title")
        if titles != ["One", "Two", "Three"]:
            raise AssertionError(f"XPath 结果异常: {titles}")
        return f"CSS/XPath 提取标题 {titles}"

    if module_available("lxml"):
        suite.case(html_section, "lxml 解析 + XPath", lxml_xpath)
    else:
        suite.record(html_section, "lxml 解析 + XPath", "SKIP", "未安装 lxml")

    def lxml_css_to_xpath() -> str:
        """CSS → XPath 翻译（原 pycrawler 的核心能力，这里做等价验证）。"""
        from lxml import html

        document = html.fromstring(HTML_SAMPLE)
        cases = {
            '//article[@class="product"]': 3,
            '//p[@class="price"]': 3,
            '//ul[@class="pager"]//li[2]': 1,
        }
        for xpath, expected in cases.items():
            found = document.xpath(xpath)
            if len(found) != expected:
                raise AssertionError(f"{xpath} 期望 {expected} 个，实得 {len(found)}")
        return f"{len(cases)} 条选择器命中数量全部正确"

    if module_available("lxml"):
        suite.case(html_section, "lxml 选择器计数", lxml_css_to_xpath)
    else:
        suite.record(html_section, "lxml 选择器计数", "SKIP", "未安装 lxml")

    def bs4_select() -> str:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(HTML_SAMPLE, "html.parser")
        prices = [node.get_text() for node in soup.select("p.price")]
        if prices != ["£7.99", "£14.99", "£21.99"]:
            raise AssertionError(f"价格提取异常: {prices}")
        return f"select('p.price') -> {prices}"

    if module_available("bs4"):
        suite.case(html_section, "beautifulsoup4 选择器", bs4_select)
    else:
        suite.record(html_section, "beautifulsoup4 选择器", "SKIP", "未安装 beautifulsoup4")

    def charset_detect() -> str:
        raw = UNICODE_SAMPLE.encode("utf-8")
        if module_available("charset_normalizer"):
            from charset_normalizer import from_bytes

            best = from_bytes(raw).best()
            guessed = best.encoding if best else "?"
        else:
            import json as _json

            _json.loads(raw.decode("utf-8"))  # 至少验证 UTF-8 解码
            guessed = "utf-8 (内置回退)"
        text = raw.decode("utf-8")
        if text != UNICODE_SAMPLE:
            raise AssertionError("解码结果不一致")
        return f"猜测编码={guessed}，解码正确"

    suite.case(html_section, "字节流编码识别", charset_detect)

    def local_http() -> str:
        """起一个本地 HTTP 服务并抓回来——不依赖外网就能验证抓取链路。"""
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

        payload = HTML_SAMPLE.encode("utf-8")

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args: Any) -> None:
                pass

            def do_GET(self) -> None:  # noqa: N802
                body = payload if self.path == "/" else b"not found"
                self.send_response(200 if self.path == "/" else 404)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_address[1]}/"
            if module_available("requests"):
                import requests

                response = requests.get(url, timeout=10)
                text, status = response.text, response.status_code
            else:
                import urllib.request

                with urllib.request.urlopen(url, timeout=10) as response:
                    text, status = response.read().decode("utf-8"), response.status
            if status != 200:
                raise AssertionError(f"HTTP 状态异常: {status}")
            from lxml import html as _html

            titles = _html.fromstring(text).xpath("//h3/a/@title")
            if titles != ["One", "Two", "Three"]:
                raise AssertionError(f"抓回后解析异常: {titles}")
            return f"本地 HTTP 200 → 解析出 {len(titles)} 条记录"
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)

    if module_available("lxml"):
        suite.case(html_section, "本地 HTTP 抓取→解析", local_http)
    else:
        suite.record(html_section, "本地 HTTP 抓取→解析", "SKIP", "未安装 lxml")

    # ---- 数据 ---------------------------------------------------------
    def numpy_math() -> str:
        import numpy as np

        values = np.arange(6, dtype=float).reshape(2, 3)
        total = float(values.sum())
        mean = float(values.mean())
        if total != 15.0 or abs(mean - 2.5) > 1e-9:
            raise AssertionError(f"计算异常 sum={total} mean={mean}")
        return f"np {np.__version__}: sum={total} mean={mean}"

    if module_available("numpy"):
        suite.case(data_section, "numpy 计算", numpy_math)
    else:
        suite.record(data_section, "numpy 计算", "SKIP", "未安装 numpy")

    def pandas_frame() -> str:
        import pandas as pd

        frame = pd.DataFrame({"name": ["甲", "乙", "丙"], "price": [7.99, 14.99, 21.99]})
        total = float(frame["price"].sum())
        if abs(total - 44.97) > 1e-6:
            raise AssertionError(f"求和异常: {total}")
        if frame["price"].dtype.kind != "f":
            raise AssertionError(f"dtype 不是浮点: {frame['price'].dtype}")
        grouped = frame.assign(flag=frame["price"] > 10).groupby("flag")["price"].count().to_dict()
        return f"pd {pd.__version__}: sum={total:.2f} 分组={grouped}"

    if module_available("pandas"):
        suite.case(data_section, "pandas 表格运算", pandas_frame)
    else:
        suite.record(data_section, "pandas 表格运算", "SKIP", "未安装 pandas")

    def csv_roundtrip() -> str:
        import csv

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "x.csv")
            rows = [["name", "price"], ["甲", "7.99"], ["乙", "14.99"]]
            with open(path, "w", encoding="utf-8-sig", newline="") as handle:
                csv.writer(handle).writerows(rows)
            with open(path, encoding="utf-8-sig", newline="") as handle:
                back = list(csv.reader(handle))
        if back != rows:
            raise AssertionError(f"CSV 往返异常: {back}")
        return f"CSV 往返正常（{len(back) - 1} 行数据 + 表头，中文正常）"

    suite.case(data_section, "CSV 读写往返", csv_roundtrip)

    # ---- 文档与图像 ---------------------------------------------------
    def pillow_roundtrip() -> str:
        from PIL import Image

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "test.png")
            image = Image.new("RGBA", (16, 12), (10, 20, 30, 255))
            image.putpixel((0, 0), (255, 0, 0, 255))
            image.save(path)
            # 必须在临时目录还活着的时候读文件大小，否则文件已被清理
            size_bytes = os.path.getsize(path)
            with Image.open(path) as handle:
                size, mode, pixel = handle.size, handle.mode, handle.convert("RGBA").getpixel((0, 0))
        if size != (16, 12) or pixel[:3] != (255, 0, 0):
            raise AssertionError(f"图像往返异常 size={size} pixel={pixel}")
        if size_bytes <= 0:
            raise AssertionError("写出的 PNG 大小为 0")
        return f"PNG {size} {mode} 像素校验通过，{size_bytes} bytes"

    if module_available("PIL"):
        suite.case(doc_section, "Pillow 图像读写", pillow_roundtrip)
    else:
        suite.record(doc_section, "Pillow 图像读写", "SKIP", "未安装 Pillow")

    def word_roundtrip() -> str:
        import docx

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "test.docx")
            document = docx.Document()
            document.add_heading("自测标题", level=1)
            document.add_paragraph(UNICODE_SAMPLE)
            document.save(path)
            reopened = docx.Document(path)
            texts = [p.text for p in reopened.paragraphs]
        if UNICODE_SAMPLE not in texts:
            raise AssertionError(f"Word 读回内容缺失: {texts}")
        return f"docx 写出/读回正常（{len(texts)} 段，含中文与 emoji）"

    if module_available("docx"):
        suite.case(doc_section, "python-docx 往返", word_roundtrip)
    else:
        suite.record(doc_section, "python-docx 往返", "SKIP", "未安装 python-docx")

    def excel_roundtrip() -> str:
        import openpyxl

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "test.xlsx")
            book = openpyxl.Workbook()
            sheet = book.active
            sheet["A1"], sheet["B1"] = "名称", "价格"
            sheet["A2"], sheet["B2"] = "甲", 7.99
            book.save(path)
            reopened = openpyxl.load_workbook(path)
            values = [reopened.active["A2"].value, reopened.active["B2"].value]
        if values != ["甲", 7.99]:
            raise AssertionError(f"Excel 读回异常: {values}")
        return f"openpyxl {openpyxl.__version__} 往返正常: {values}"

    if module_available("openpyxl"):
        suite.case(doc_section, "openpyxl Excel 往返", excel_roundtrip)
    else:
        suite.record(doc_section, "openpyxl Excel 往返", "SKIP", "未安装 openpyxl")

    def xlsxwriter_write() -> str:
        import xlsxwriter

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "test.xlsx")
            with xlsxwriter.Workbook(path) as book:
                sheet = book.add_worksheet()
                sheet.write_row(0, 0, ["名称", "价格"])
                sheet.write_row(1, 0, ["甲", 7.99])
            size = os.path.getsize(path)
        if size <= 0:
            raise AssertionError("写出的文件为空")
        return f"XlsxWriter {xlsxwriter.__version__} 写出 {size} bytes"

    if module_available("xlsxwriter"):
        suite.case(doc_section, "XlsxWriter 写出", xlsxwriter_write)
    else:
        suite.record(doc_section, "XlsxWriter 写出", "SKIP", "未安装 XlsxWriter")

    def pptx_roundtrip() -> str:
        import pptx

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "test.pptx")
            deck = pptx.Presentation()
            slide = deck.slides.add_slide(deck.slide_layouts[5])
            slide.shapes.title.text = "自测"
            box = slide.shapes.add_textbox(0, 0, 100, 50)
            box.text_frame.text = UNICODE_SAMPLE
            deck.save(path)
            reopened = pptx.Presentation(path)
            shapes = len(reopened.slides[0].shapes)
        if shapes < 2:
            raise AssertionError(f"幻灯片形状数异常: {shapes}")
        return f"python-pptx 写出/读回正常（{shapes} 个形状）"

    if module_available("pptx"):
        suite.case(doc_section, "python-pptx 往返", pptx_roundtrip)
    else:
        suite.record(doc_section, "python-pptx 往返", "SKIP", "未安装 python-pptx")


# --------------------------------------------------------------------------
# 5. 真实网络（--live 才跑）
# --------------------------------------------------------------------------
def network_reachable(url: str, timeout: float = 8.0) -> bool:
    import urllib.request

    try:
        request = urllib.request.Request(url, headers={"User-Agent": f"selftest/{VERSION}"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status < 500
    except Exception:
        return False


def section_live() -> None:
    section = "真实网络"

    if not network_reachable(LIVE_URL):
        suite.record(section, "连通性", "SKIP", f"无法访问 {LIVE_URL}（离线或超时）")
        suite.record(section, "抓取 + 解析", "SKIP", "网络不可达")
        return

    fetch_state: dict[str, Any] = {}

    def fetch() -> str:
        if module_available("requests"):
            import requests

            started = time.perf_counter()
            response = requests.get(LIVE_URL, timeout=20, headers={"User-Agent": f"selftest/{VERSION}"})
            elapsed = time.perf_counter() - started
            response.raise_for_status()
            # requests 常把无 charset 的页面猜成 ISO-8859-1，这里显式按内容解码
            body = response.content
            text = body.decode("utf-8", errors="replace")
            fetch_state.update({"text": text, "bytes": len(body), "status": response.status_code, "elapsed": elapsed})
            return f"requests {response.status_code} · {len(body) / 1024:.1f} KB · {elapsed:.2f}s"
        import urllib.request

        started = time.perf_counter()
        request = urllib.request.Request(LIVE_URL, headers={"User-Agent": f"selftest/{VERSION}"})
        with urllib.request.urlopen(request, timeout=20) as response:
            body = response.read()
            status = response.status
        elapsed = time.perf_counter() - started
        fetch_state.update(
            {"text": body.decode("utf-8", errors="replace"), "bytes": len(body), "status": status, "elapsed": elapsed}
        )
        return f"urllib {status} · {len(body) / 1024:.1f} KB · {elapsed:.2f}s"

    suite.case(section, "抓取", fetch)

    def parse() -> str:
        if "text" not in fetch_state:
            raise AssertionError("上一步抓取未成功")
        from lxml import html as _html

        document = _html.fromstring(fetch_state["text"])
        titles = document.xpath("//article[contains(@class,'product_pod')]//h3/a/@title")
        prices = document.xpath("//article[contains(@class,'product_pod')]//p[contains(@class,'price_color')]/text()")
        nexts = document.xpath("//li[contains(@class,'next')]/a/@href")
        if len(titles) != LIVE_EXPECT_ITEMS:
            raise AssertionError(f"期望 {LIVE_EXPECT_ITEMS} 本书，实得 {len(titles)}")
        if not prices or "£" not in prices[0]:
            raise AssertionError(f"价格解析异常: {prices[:3]}")
        return f"{len(titles)} 本书 · 首页价格 {prices[0]} · 下一页 {nexts[:1]}"

    if module_available("lxml"):
        suite.case(section, "抓取结果解析", parse)
    else:
        suite.record(section, "抓取结果解析", "SKIP", "未安装 lxml")


# --------------------------------------------------------------------------
# 6. pip / 包管理健康度
# --------------------------------------------------------------------------
def section_pip(versions: dict[str, str]) -> None:
    section = "包管理"

    def pip_version() -> str:
        import importlib.metadata as metadata

        return f"pip {metadata.version('pip')}"

    suite.case(section, "pip 可用", pip_version)

    def installed_count() -> str:
        import importlib.metadata as metadata

        names = sorted({d.metadata["Name"] for d in metadata.distributions() if d.metadata["Name"]}, key=str.lower)
        return f"已安装 {len(names)} 个发行包"

    suite.case(section, "已安装包清单", installed_count)

    missing = [package for module, package, _ in LIBS if not module_available(module)]
    if missing:
        suite.record(section, "工作区所需依赖齐全", "FAIL", error=f"缺失: {' '.join(missing)}", detail="")
    else:
        suite.record(section, "工作区所需依赖齐全", "PASS", f"{len(LIBS)} 个库全部就绪")


# --------------------------------------------------------------------------
# 输出
# --------------------------------------------------------------------------
def render(suite: Suite, info: dict[str, Any], versions: dict[str, str], quiet: bool, elapsed: float) -> None:
    icon = {"PASS": "PASS", "FAIL": "FAIL", "SKIP": "SKIP"}
    print("=" * 78)
    print(f"工作区环境自测  v{VERSION}")
    print("=" * 78)
    if info:
        print(f"  解释器 : {info.get('version')} {info.get('implementation')} "
              f"{info.get('bits')}bit{'  [free-threaded]' if info.get('free_threaded') else ''}")
        print(f"  路径   : {info.get('executable')}")
        print(f"  库目录 : {info.get('site_packages')}")
        print(f"  虚拟环境: {'是' if info.get('venv') else '否（使用系统环境）'}")
    print("-" * 78)

    current = None
    for result in suite.results:
        if result.section != current:
            current = result.section
            print(f"\n[{current}]")
        if quiet and result.status == "PASS":
            continue
        detail = result.detail or result.error
        print(f"  {icon[result.status]}  {result.name:<34} {detail}")
        if result.status == "FAIL":
            print()

    print("\n" + "=" * 78)
    total = len(suite.results)
    print(f"  合计 {total} 项：{suite.passed} 通过 / {len(suite.failed)} 失败 / {len(suite.skipped)} 跳过"
          f"　用时 {elapsed:.2f}s")
    if suite.failed:
        print("\n  失败明细：")
        for result in suite.failed:
            print(f"    ✘ [{result.section}] {result.name}: {result.error}")
    skipped = suite.skipped
    if skipped and not quiet:
        print("\n  跳过项：")
        for result in skipped:
            print(f"    ○ [{result.section}] {result.name}: {result.detail}")
    print("=" * 78)
    if not suite.failed:
        print("  结论：环境可用 ✔" + ("（含真实网络验证）" if any(r.section == "真实网络" and r.status == "PASS" for r in suite.results) else ""))
    else:
        print("  结论：存在失败项，环境未就绪 ✘")
    print("=" * 78)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="环境自测.py",
        description="工作区 Python 环境自测：解释器、标准库、依赖库、真实功能、可选网络。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python 环境自测.py                 离线自测\n"
            "  python 环境自测.py --live          追加真实网络抓取\n"
            "  python 环境自测.py --json out.json 写出机器可读报告\n"
            "  python 环境自测.py --quiet         只看失败项\n"
            "\n退出码: 0=全部通过(允许跳过)  1=有失败  2=自测脚本自身异常"
        ),
    )
    parser.add_argument("--live", action="store_true", help="追加真实网络抓取与解析")
    parser.add_argument("--json", metavar="PATH", help="把结果写成 JSON 报告")
    parser.add_argument("--log", metavar="PATH", help="把整份控制台输出另存为文本文件")
    parser.add_argument("--pause", action="store_true",
                        help="结束时等待回车（双击运行时用，防止窗口一闪而过）")
    parser.add_argument("--no-pause", action="store_true",
                        help="强制不等待回车（自动化脚本用）")
    parser.add_argument("--quiet", "-q", action="store_true", help="只输出失败项与总结")
    parser.add_argument("--version", action="version", version=f"selftest {VERSION}")
    return parser


def tee_to(path: str) -> str:
    """把 stdout/stderr 同时镜像到 ``path``，这样窗口关掉也留得下结果。

    返回日志文件的绝对路径；任何失败都静默降级，绝不让记录功能本身弄挂脚本。
    """
    absolute = os.path.abspath(path)
    try:
        handle = open(absolute, "w", encoding="utf-8", buffering=1)

        class Tee:
            """写原始流的同时写一份到文件。"""

            def __init__(self, original: Any, mirror: Any) -> None:
                self._original = original
                self._mirror = mirror

            def write(self, text: str) -> int:
                try:
                    self._mirror.write(text)
                except Exception:
                    pass
                if self._original is None:
                    return len(text)
                return self._original.write(text)

            def flush(self) -> None:
                for target in (self._mirror, self._original):
                    try:
                        if target is not None:
                            target.flush()
                    except Exception:
                        pass

            def __getattr__(self, name: str) -> Any:
                if self._original is None:
                    raise AttributeError(name)
                return getattr(self._original, name)

        for stream_name in ("stdout", "stderr"):
            setattr(sys, stream_name, Tee(getattr(sys, stream_name, None), handle))
        return absolute
    except Exception:  # noqa: BLE001
        return ""


def has_real_console() -> bool:
    """当前进程是否真的挂着一个 Windows 控制台。

    用 GetConsoleMode 判断：管道、重定向、服务环境下取不到控制台句柄，
    此时必须**不要**用 msvcrt.getch()，否则会永久阻塞（CI 卡死的经典原因）。
    """
    if os.name != "nt":
        return False
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        if handle in (0, -1):
            return False
        mode = wintypes.DWORD()
        return bool(kernel32.GetConsoleMode(wintypes.HANDLE(handle), ctypes.byref(mode)))
    except Exception:
        return False


def wait_for_keypress(timeout: float = 30.0) -> str:
    """等待一次按键，最多 ``timeout`` 秒，返回所用方式。

    优先用 msvcrt 直接读控制台键盘缓冲区 —— 它**不依赖 stdin 重定向**。实测
    ``set /p`` 与 ``pause`` 在 stdin 被继承/重定向时会立即返回，窗口照样闪退；
    msvcrt.getch() 读的是控制台输入缓冲区，因此必定阻塞到真的按键。

    倒计时是刻意设计的：即便有人在自动化环境里意外触发了暂停，最多等 timeout
    秒就自行退出，**永远不会把流程挂死**。无控制台时立即返回。
    """
    if has_real_console():
        try:
            import msvcrt
            import time as _time

            while msvcrt.kbhit():  # 丢掉遗留按键，避免"没按就过"
                msvcrt.getch()
            deadline = _time.monotonic() + timeout
            while True:
                remaining = deadline - _time.monotonic()
                if remaining <= 0:
                    return f"超时 {timeout:.0f} 秒自动关闭"
                print(f"\r按任意键关闭窗口 ... {remaining:4.1f} 秒后自动关闭 ", end="", flush=True)
                if msvcrt.kbhit():
                    msvcrt.getch()
                    return "按键"
                _time.sleep(0.1)
        except Exception:
            pass
    try:
        input()
        return "input"
    except (EOFError, KeyboardInterrupt, OSError):
        return "无控制台，未等待"


def pause_if_interactive() -> None:
    """交互式运行时保持窗口不关闭（双击 .py 场景）。"""
    print("\n" + "-" * 78, flush=True)
    method = wait_for_keypress()
    print(f"\n（{method}）")


def should_pause(args: argparse.Namespace) -> bool:
    """判断是否需要「按任意键关闭窗口」。

    双击 .py 时 Windows 会新开一个控制台：脚本跑完窗口立刻消失，看不到任何
    结果（用户口中的"闪退"）。此时 stdout 是终端（isatty 为真），因此自动暂停。

    以下情况绝不暂停，避免卡死自动化流程：
      * 显式给了任何命令行参数（说明是从终端里调用的）
      * stdout 不是终端（管道、重定向、CI）
      * 环境变量 SELFTEST_NO_PAUSE=1（自测.bat 会设置，暂停由它自己负责）
    手动覆盖：--pause 强制等待，--no-pause 强制不等。
    """
    if getattr(args, "no_pause", False):
        return False
    if getattr(args, "pause", False):
        return True
    if os.environ.get("SELFTEST_NO_PAUSE"):
        return False
    if sys.argv[1:]:
        return False
    try:
        return bool(sys.stdout is not None and sys.stdout.isatty())
    except Exception:
        return False


def main(argv: list[str] | None = None) -> int:
    # 必须先于 parse_args：argparse 的 --help/--version 会自己 print 再 sys.exit，
    # 若此时 stdout 还是 GBK，帮助文本就会输出成非法字节。
    global ORIGINAL_STDIO_ENCODING, CONSOLE_UTF8
    ORIGINAL_STDIO_ENCODING, CONSOLE_UTF8 = force_utf8_output()

    args = build_parser().parse_args(argv)

    log_path = ""
    if args.log:
        log_path = tee_to(args.log)

    started = time.perf_counter()
    try:
        info = section_interpreter()
        section_stdlib()
        versions = section_imports()
        section_functional()
        if args.live:
            section_live()
        section_pip(versions)
    except Exception:  # noqa: BLE001 - 自测脚本自身出错
        traceback.print_exc()
        print("\n自测脚本自身异常，无法完成检查。", file=sys.stderr)
        return 2
    elapsed = time.perf_counter() - started

    render(suite, info, versions, args.quiet, elapsed)

    if args.json:
        report = {
            "selftest_version": VERSION,
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "interpreter": info,
            "library_versions": versions,
            "summary": {
                "total": len(suite.results),
                "passed": suite.passed,
                "failed": len(suite.failed),
                "skipped": len(suite.skipped),
                "seconds": round(elapsed, 3),
            },
            "results": [
                {
                    "section": r.section,
                    "name": r.name,
                    "status": r.status,
                    "detail": r.detail,
                    "error": r.error,
                    "seconds": round(r.seconds, 4),
                }
                for r in suite.results
            ],
        }
        with open(args.json, "w", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
        print(f"JSON 报告 -> {os.path.abspath(args.json)}")

    if log_path:
        print(f"文本日志 -> {log_path}")

    if should_pause(args):
        pause_if_interactive()

    return 1 if suite.failed else 0


def run() -> int:
    """真正的入口：确保结束前把缓冲区落盘，双击场景下窗口不留错误。"""
    try:
        return main()
    except KeyboardInterrupt:
        print("\n已中断 (Ctrl+C)。", file=sys.stderr)
        return 130
    except SystemExit as exc:  # argparse 的 --help/--version
        return int(exc.code or 0)
    finally:
        for stream_name in ("stdout", "stderr"):
            stream = getattr(sys, stream_name, None)
            try:
                if stream is not None:
                    stream.flush()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(run())
